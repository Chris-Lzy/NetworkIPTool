namespace NetworkIPTool;

/// <summary>
/// 适配器重命名对话框。控件与布局见 RenameDialog.Designer.cs。
/// </summary>
public partial class RenameDialog : Form
{
    public string NewName { get; private set; } = "";

    public RenameDialog(string currentName)
    {
        InitializeComponent();
        _txtName.Text = currentName;
    }

    private void BtnOk_Click(object? sender, EventArgs e)
    {
        NewName = _txtName.Text.Trim();
        Close();
    }
}
