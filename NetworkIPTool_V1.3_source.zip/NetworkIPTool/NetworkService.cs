using System.Diagnostics;
using System.Management;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace NetworkIPTool;

/// <summary>
/// 网卡信息、当前 IP 查询，以及通过 netsh 设置静态 IP / DHCP / 重命名。
/// 假定进程已通过清单以管理员身份运行。
/// </summary>
public static class NetworkService
{
    public sealed class NetworkAdapterInfo
    {
        public string Name { get; init; } = "";
        public string Status { get; init; } = "";
    }

    /// <summary>
    /// 枚举 NetConnectionStatus 为已连接(2)或已断开(0)的网卡。
    /// </summary>
    public static List<NetworkAdapterInfo> GetNetworkAdapters()
    {
        var list = new List<NetworkAdapterInfo>();
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT * FROM Win32_NetworkAdapter WHERE NetConnectionStatus = 2 OR NetConnectionStatus = 0");

            foreach (ManagementObject item in searcher.Get())
            {
                using (item)
                {
                    string name = item["NetConnectionID"]?.ToString()
                                  ?? item["Name"]?.ToString()
                                  ?? "Unknown";
                    int status = Convert.ToInt32(item["NetConnectionStatus"]);
                    list.Add(new NetworkAdapterInfo
                    {
                        Name = name,
                        Status = status == 2 ? "已连接" : "已断开"
                    });
                }
            }
        }
        catch
        {
            // WMI 不可用时返回空列表
        }

        return list;
    }

    public static bool SetStaticIP(
        string adapterName,
        string ip,
        string? mask,
        string? gateway,
        string? dns1,
        string? dns2)
    {
        try
        {
            string gw = string.IsNullOrEmpty(gateway) ? "none" : gateway!;
            string maskValue = string.IsNullOrEmpty(mask) ? "255.255.255.0" : mask!;

            if (!RunNetsh($"interface ip set address name=\"{adapterName}\" static {ip} {maskValue} {gw} 1"))
            {
                return false;
            }

            if (!string.IsNullOrEmpty(dns1))
            {
                RunNetsh($"interface ip set dns name=\"{adapterName}\" static {dns1} primary");
            }

            if (!string.IsNullOrEmpty(dns2))
            {
                RunNetsh($"interface ip add dns name=\"{adapterName}\" {dns2} index=2");
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    public static bool SetDhcp(string adapterName)
    {
        try
        {
            RunNetsh($"interface ip set address name=\"{adapterName}\" dhcp");
            RunNetsh($"interface ip set dns name=\"{adapterName}\" dhcp");
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static bool RenameAdapter(string oldName, string newName)
    {
        return RunNetsh($"interface set interface name=\"{oldName}\" newname=\"{newName}\"");
    }

    public static string GetCurrentIP(string adapterName)
    {
        try
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.Name != adapterName && ni.Description != adapterName)
                {
                    continue;
                }

                foreach (UnicastIPAddressInformation addr in ni.GetIPProperties().UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == AddressFamily.InterNetwork)
                    {
                        return addr.Address.ToString();
                    }
                }
            }

            // 回退到 netsh 输出解析
            var startInfo = new ProcessStartInfo
            {
                FileName = "netsh",
                Arguments = $"interface ip show addresses name=\"{adapterName}\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using Process? process = Process.Start(startInfo);
            if (process == null)
            {
                return "";
            }

            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);

            foreach (string line in output.Split('\n'))
            {
                string trimmed = line.Trim();
                // 英文 / 中文 netsh 输出
                if (trimmed.StartsWith("IP Address:", StringComparison.OrdinalIgnoreCase)
                    || trimmed.StartsWith("IP 地址:", StringComparison.OrdinalIgnoreCase)
                    || trimmed.StartsWith("IP 地址：", StringComparison.OrdinalIgnoreCase))
                {
                    int colon = trimmed.IndexOf(':');
                    if (colon < 0)
                    {
                        colon = trimmed.IndexOf('：');
                    }

                    if (colon >= 0)
                    {
                        return trimmed[(colon + 1)..].Trim();
                    }
                }
            }
        }
        catch
        {
            // ignore
        }

        return "";
    }

    /// <summary>
    /// 运行 netsh。应用已通过清单要求管理员，因此不再使用 Verb=runas
    /// （Verb 与 UseShellExecute=false 无法同时生效）。
    /// </summary>
    private static bool RunNetsh(string arguments)
    {
        try
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = "netsh",
                Arguments = arguments,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using Process? process = Process.Start(startInfo);
            if (process == null)
            {
                return false;
            }

            process.WaitForExit(10000);
            return process.ExitCode == 0;
        }
        catch
        {
            return false;
        }
    }
}
