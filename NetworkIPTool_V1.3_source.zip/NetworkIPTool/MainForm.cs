using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using NetworkIPTool.Models;

namespace NetworkIPTool;

/// <summary>
/// 主窗体：业务逻辑与事件处理。控件声明与布局见 MainForm.Designer.cs（可在 VS 设计器中打开）。
/// </summary>
public partial class MainForm : Form
{
    // ---- 运行时布局常量（96 DPI 逻辑像素）----
    private const string UiStateVersion = "1.3";
    private static readonly Size DefaultClientLogical = new(1100, 680); // 默认客户区：7 列无横向滚动、可见约 12 行
    private static readonly Size MinClientLogical = new(1024, 600);     // 最小客户区
    private const int GridRowHeight = 34;

    private static readonly Color ColorPrimary = Color.FromArgb(46, 117, 182);      // #2E75B6
    private static readonly Color ColorPrimaryDark = Color.FromArgb(38, 95, 148);   // #265F94
    private static readonly Color ColorAltRow = Color.FromArgb(249, 251, 253);      // #F9FBFD

    private readonly string _configPath;
    private AppConfig _config;
    private List<NetworkService.NetworkAdapterInfo> _adapters = new();

    private bool _suppressCellSave;
    private bool _restoringUi;

    public MainForm()
    {
        _configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ip_config.xml");
        _config = new AppConfig();

        InitializeComponent();

        // ---- 以下为运行时才能确定的内容，不放进 InitializeComponent ----
        ApplyVersionInfo();
        ScaleGridMetrics(DeviceDpi);
        DpiChanged += MainForm_DpiChanged;

        // 先读配置；窗口尺寸在 Load（句柄已创建、DPI 已确定）时还原
        LoadConfig();
    }

    private void MainForm_Load(object? sender, EventArgs e)
    {
        ApplyUiStateWindow();
        // 句柄创建后再枚举网卡（WMI），保证下拉框可用
        RefreshAdapters(selectByUiState: true);
    }

    private void LinkSite_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://loncoo.com",
                UseShellExecute = true
            });
        }
        catch
        {
            // ignore
        }
    }

    // ----------------- 版本 / 编译日期 -----------------

    /// <summary>标题栏与品牌栏右侧显示版本号和编译日期（编译时由 csproj 写入程序集元数据）。</summary>
    private void ApplyVersionInfo()
    {
        Assembly asm = typeof(MainForm).Assembly;
        string version = asm.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion
                         ?? asm.GetName().Version?.ToString(3)
                         ?? "";
        int plus = version.IndexOf('+');
        if (plus >= 0)
        {
            version = version[..plus];
        }

        string buildDate = asm.GetCustomAttributes<AssemblyMetadataAttribute>()
                               .FirstOrDefault(a => a.Key == "BuildDate")?.Value
                           ?? "";

        Text = $"网络适配器 IP 配置工具 V{version}";
        _lblVersion.Text = string.IsNullOrEmpty(buildDate)
            ? $"版本 V{version}"
            : $"版本 V{version}  编译日期 {buildDate}";
    }

    // ----------------- 表格外观（仅显示，不含业务） -----------------

    /// <summary>
    /// DataGridView 的行高、列最小宽、单元格 Padding 不参与 AutoScale，按 DPI 换算一次；
    /// 跨不同缩放的显示器拖动时（DpiChanged）再换算一次。
    /// </summary>
    private void ScaleGridMetrics(int dpi)
    {
        int S(int v) => (int)Math.Round(v * dpi / 96.0);
        Padding P(int l, int t, int r, int b) => new(S(l), S(t), S(r), S(b));

        // 列最小宽之和 = 80+100+100+100+90+90+90 = 650 逻辑 px，最小窗口下也不会出现横向滚动
        ProfileName.MinimumWidth = S(80);
        IP.MinimumWidth = S(100);
        SubnetMask.MinimumWidth = S(100);
        Gateway.MinimumWidth = S(100);
        DNS1.MinimumWidth = S(90);
        DNS2.MinimumWidth = S(90);
        Apply.MinimumWidth = S(90);

        _dgvProfiles.ColumnHeadersDefaultCellStyle.Padding = P(4, 8, 4, 8);
        _dgvProfiles.DefaultCellStyle.Padding = P(6, 0, 6, 0);
        Apply.DefaultCellStyle.Padding = P(8, 4, 8, 4);

        _dgvProfiles.RowTemplate.Height = S(GridRowHeight);
        foreach (DataGridViewRow row in _dgvProfiles.Rows)
        {
            row.Height = S(GridRowHeight);
        }
    }

    private void MainForm_DpiChanged(object? sender, DpiChangedEventArgs e)
    {
        ScaleGridMetrics(e.DeviceDpiNew);
    }

    /// <summary>
    /// 统一单元格配色：「应用此 IP」每一行都是 #2E75B6 蓝底白字；
    /// 其它列在偶数行（第 2、4… 行）画浅色隔行底。
    /// 不再使用 AlternatingRowsDefaultCellStyle——它的优先级高于列样式，会把按钮列底色盖成浅色。
    /// </summary>
    private void DgvProfiles_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.CellStyle == null)
        {
            return;
        }

        if (_dgvProfiles.Columns[e.ColumnIndex].Name == "Apply")
        {
            e.CellStyle.BackColor = ColorPrimary;
            e.CellStyle.ForeColor = Color.White;
            e.CellStyle.SelectionBackColor = ColorPrimaryDark;
            e.CellStyle.SelectionForeColor = Color.White;
        }
        else if (e.RowIndex % 2 == 1)
        {
            e.CellStyle.BackColor = ColorAltRow;
        }
    }

    // ----------------- UI 状态 -----------------

    /// <summary>
    /// 在 Load 中执行（句柄已创建、DeviceDpi 为实际显示器 DPI），直接按物理像素设置，保证缩放只发生一次。
    /// 保存的尺寸满足以下条件才使用：UiState.Version 一致、保存时 DPI 与当前一致、不小于最小尺寸；否则用默认尺寸居中。
    /// </summary>
    private void ApplyUiStateWindow()
    {
        UiState ui = _config.UiState ?? new UiState();
        _config.UiState = ui;

        Size minSize = SizeFromClientSize(LogicalToDeviceUnits(MinClientLogical));
        Size defaultSize = SizeFromClientSize(LogicalToDeviceUnits(DefaultClientLogical));

        bool sameLayout = ui.Version == UiStateVersion && ui.WindowDpi == DeviceDpi;
        bool sizeValid = sameLayout && ui.WindowWidth >= minSize.Width && ui.WindowHeight >= minSize.Height;

        int w = sizeValid ? ui.WindowWidth : defaultSize.Width;
        int h = sizeValid ? ui.WindowHeight : defaultSize.Height;

        var saved = new Rectangle(ui.WindowX, ui.WindowY, w, h);
        bool usePos = sameLayout && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(saved));

        // 目标屏幕工作区：小屏高缩放（如 1366×768 @150%）时，最小尺寸与窗口尺寸都收缩到工作区内
        Rectangle area = usePos
            ? Screen.FromRectangle(saved).WorkingArea
            : Screen.FromControl(this).WorkingArea;
        MinimumSize = new Size(Math.Min(minSize.Width, area.Width), Math.Min(minSize.Height, area.Height));
        w = Math.Clamp(w, MinimumSize.Width, area.Width);
        h = Math.Clamp(h, MinimumSize.Height, area.Height);

        WindowState = FormWindowState.Normal;
        Size = new Size(w, h);
        if (usePos)
        {
            Location = new Point(
                Math.Clamp(ui.WindowX, area.Left, area.Right - w),
                Math.Clamp(ui.WindowY, area.Top, area.Bottom - h));
        }
        else
        {
            Location = new Point(area.Left + (area.Width - w) / 2, area.Top + (area.Height - h) / 2);
        }

        if (string.Equals(ui.WindowState, "Maximized", StringComparison.OrdinalIgnoreCase))
        {
            WindowState = FormWindowState.Maximized;
        }
        // Minimized / 未知 → Normal
    }

    private void CaptureUiState()
    {
        _config.UiState ??= new UiState();
        UiState ui = _config.UiState;

        // 用 RestoreBounds 保存最大化前的尺寸
        Rectangle bounds = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
        ui.WindowX = bounds.X;
        ui.WindowY = bounds.Y;
        ui.WindowWidth = bounds.Width;
        ui.WindowHeight = bounds.Height;
        ui.WindowState = WindowState == FormWindowState.Maximized ? "Maximized" : "Normal";
        ui.Version = UiStateVersion;
        ui.WindowDpi = DeviceDpi;

        if (_cmbAdapters.SelectedIndex >= 0 && _cmbAdapters.SelectedIndex < _adapters.Count)
        {
            ui.LastAdapterName = _adapters[_cmbAdapters.SelectedIndex].Name;
        }

        if (_dgvProfiles.SelectedRows.Count > 0)
        {
            ui.LastProfileRowIndex = _dgvProfiles.SelectedRows[0].Index;
        }
        else if (_dgvProfiles.CurrentCell != null)
        {
            ui.LastProfileRowIndex = _dgvProfiles.CurrentCell.RowIndex;
        }
        else
        {
            ui.LastProfileRowIndex = -1;
        }
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        try
        {
            SaveCurrentConfig();
            CaptureUiState();
            SaveConfig();
        }
        catch
        {
            // 关闭时尽力保存，不阻断退出
        }
    }

    // ----------------- 适配器 / 配置 -----------------

    private void RefreshAdapters(bool selectByUiState = false)
    {
        string? preferName = null;
        if (selectByUiState && !string.IsNullOrEmpty(_config.UiState?.LastAdapterName))
        {
            preferName = _config.UiState!.LastAdapterName;
        }
        else if (_cmbAdapters.SelectedIndex >= 0 && _cmbAdapters.SelectedIndex < _adapters.Count)
        {
            preferName = _adapters[_cmbAdapters.SelectedIndex].Name;
        }

        _adapters = NetworkService.GetNetworkAdapters();
        _cmbAdapters.Items.Clear();
        foreach (var adapter in _adapters)
        {
            _cmbAdapters.Items.Add($"{adapter.Name} [{adapter.Status}]");
        }

        if (_cmbAdapters.Items.Count == 0)
        {
            return;
        }

        int index = 0;
        if (!string.IsNullOrEmpty(preferName))
        {
            int found = _adapters.FindIndex(a => a.Name == preferName);
            if (found >= 0)
            {
                index = found;
            }
        }

        _restoringUi = selectByUiState;
        _cmbAdapters.SelectedIndex = index;
        _restoringUi = false;
    }

    private void CmbAdapters_SelectedIndexChanged(object? sender, EventArgs e)
    {
        LoadProfilesForAdapter();
        UpdateCurrentIp();

        if (_restoringUi && _config.UiState != null)
        {
            int row = _config.UiState.LastProfileRowIndex;
            if (row >= 0 && row < _dgvProfiles.Rows.Count)
            {
                _dgvProfiles.ClearSelection();
                _dgvProfiles.Rows[row].Selected = true;
                if (_dgvProfiles.Columns.Count > 0)
                {
                    _dgvProfiles.CurrentCell = _dgvProfiles.Rows[row].Cells[0];
                }
            }
        }
    }

    private void LoadProfilesForAdapter()
    {
        _suppressCellSave = true;
        _dgvProfiles.Rows.Clear();

        if (_cmbAdapters.SelectedIndex < 0)
        {
            _suppressCellSave = false;
            return;
        }

        string adapterName = _adapters[_cmbAdapters.SelectedIndex].Name;
        AdapterProfile? profile = _config.Adapters.FirstOrDefault(a => a.AdapterName == adapterName);
        if (profile == null)
        {
            profile = new AdapterProfile { AdapterName = adapterName };
            for (int i = 0; i < 5; i++)
            {
                profile.Profiles.Add(new IPConfig
                {
                    ProfileName = $"配置 {i + 1}",
                    SubnetMask = "255.255.255.0"
                });
            }

            _config.Adapters.Add(profile);
        }

        foreach (IPConfig cfg in profile.Profiles)
        {
            _dgvProfiles.Rows.Add(
                cfg.ProfileName,
                cfg.IP,
                cfg.SubnetMask,
                cfg.Gateway,
                cfg.DNS1,
                cfg.DNS2);
        }

        _suppressCellSave = false;
    }

    private void UpdateCurrentIp()
    {
        if (_cmbAdapters.SelectedIndex < 0)
        {
            _lblCurrentIp.Text = "当前 IP: -";
            return;
        }

        string name = _adapters[_cmbAdapters.SelectedIndex].Name;
        string ip = NetworkService.GetCurrentIP(name);
        _lblCurrentIp.Text = string.IsNullOrEmpty(ip) ? "当前 IP: (未设置)" : $"当前 IP: {ip}";
    }

    // ----------------- 表格 / 按钮 -----------------

    private void DgvProfiles_CellClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0 || _dgvProfiles.Columns[e.ColumnIndex].Name != "Apply")
        {
            return;
        }

        if (_cmbAdapters.SelectedIndex < 0)
        {
            return;
        }

        string name = _adapters[_cmbAdapters.SelectedIndex].Name;
        DataGridViewRow row = _dgvProfiles.Rows[e.RowIndex];
        string? ip = row.Cells["IP"].Value?.ToString()?.Trim();
        string? mask = row.Cells["SubnetMask"].Value?.ToString()?.Trim();
        string? gateway = row.Cells["Gateway"].Value?.ToString()?.Trim();
        string? dns1 = row.Cells["DNS1"].Value?.ToString()?.Trim();
        string? dns2 = row.Cells["DNS2"].Value?.ToString()?.Trim();

        if (string.IsNullOrEmpty(ip))
        {
            MessageBox.Show("IP 地址不能为空！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        DialogResult confirm = MessageBox.Show(
            $"确认将 [{name}] 设置为:\n\nIP: {ip}\n掩码: {mask}\n网关: {gateway}\nDNS: {dns1} / {dns2}",
            "确认",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (confirm != DialogResult.Yes)
        {
            return;
        }

        SetStatus("正在应用 IP 配置...");
        if (NetworkService.SetStaticIP(name, ip, mask, gateway, dns1, dns2))
        {
            SetStatus("✓ 已成功应用: " + ip);
            MessageBox.Show("IP 配置已应用！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            UpdateCurrentIp();
        }
        else
        {
            SetStatus("✗ 应用失败，请以管理员权限运行");
            MessageBox.Show("设置失败！请确保以管理员权限运行此程序。", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void DgvProfiles_CellValueChanged(object? sender, DataGridViewCellEventArgs e)
    {
        if (_suppressCellSave || e.RowIndex < 0)
        {
            return;
        }

        SaveCurrentConfig();
        SaveConfig();
    }

    private void BtnRefresh_Click(object? sender, EventArgs e)
    {
        RefreshAdapters(selectByUiState: false);
        SetStatus("适配器列表已刷新");
    }

    private void BtnRename_Click(object? sender, EventArgs e)
    {
        if (_cmbAdapters.SelectedIndex < 0)
        {
            return;
        }

        string oldName = _adapters[_cmbAdapters.SelectedIndex].Name;
        using var dialog = new RenameDialog(oldName);
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        string newName = dialog.NewName;
        if (string.IsNullOrWhiteSpace(newName) || newName == oldName)
        {
            return;
        }

        SetStatus("正在重命名适配器...");
        if (NetworkService.RenameAdapter(oldName, newName))
        {
            AdapterProfile? profile = _config.Adapters.FirstOrDefault(a => a.AdapterName == oldName);
            if (profile != null)
            {
                profile.AdapterName = newName;
            }

            if (_config.UiState != null && _config.UiState.LastAdapterName == oldName)
            {
                _config.UiState.LastAdapterName = newName;
            }

            SaveConfig();
            RefreshAdapters(selectByUiState: false);

            // 尽量选中新名称
            int idx = _adapters.FindIndex(a => a.Name == newName);
            if (idx >= 0)
            {
                _cmbAdapters.SelectedIndex = idx;
            }

            SetStatus($"✓ 已重命名: {oldName} → {newName}");
        }
        else
        {
            SetStatus("✗ 重命名失败，请以管理员权限运行");
            MessageBox.Show("重命名失败！请确保以管理员权限运行。", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void BtnSave_Click(object? sender, EventArgs e)
    {
        SaveCurrentConfig();
        CaptureUiState();
        SaveConfig();
        SetStatus("✓ 配置已保存到 ip_config.xml");
        MessageBox.Show("配置已保存！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void BtnAddProfile_Click(object? sender, EventArgs e)
    {
        if (_cmbAdapters.SelectedIndex < 0)
        {
            return;
        }

        string adapterName = _adapters[_cmbAdapters.SelectedIndex].Name;
        AdapterProfile? profile = _config.Adapters.FirstOrDefault(a => a.AdapterName == adapterName);
        if (profile == null)
        {
            return;
        }

        int n = _dgvProfiles.Rows.Count + 1;
        profile.Profiles.Add(new IPConfig
        {
            ProfileName = $"配置 {n}",
            SubnetMask = "255.255.255.0"
        });

        _suppressCellSave = true;
        _dgvProfiles.Rows.Add($"配置 {n}", "", "255.255.255.0", "", "", "");
        _suppressCellSave = false;
    }

    private void BtnDelProfile_Click(object? sender, EventArgs e)
    {
        if (_dgvProfiles.SelectedRows.Count == 0)
        {
            return;
        }

        int index = _dgvProfiles.SelectedRows[0].Index;
        _dgvProfiles.Rows.RemoveAt(index);
        SaveCurrentConfig();
    }

    private void BtnDhcp_Click(object? sender, EventArgs e)
    {
        if (_cmbAdapters.SelectedIndex < 0)
        {
            return;
        }

        string name = _adapters[_cmbAdapters.SelectedIndex].Name;
        DialogResult confirm = MessageBox.Show(
            $"确认将 [{name}] 恢复为 DHCP 自动获取？",
            "确认",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (confirm != DialogResult.Yes)
        {
            return;
        }

        SetStatus("正在恢复 DHCP...");
        if (NetworkService.SetDhcp(name))
        {
            SetStatus("✓ 已恢复 DHCP");
            MessageBox.Show("已恢复为 DHCP！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            UpdateCurrentIp();
        }
        else
        {
            SetStatus("✗ 恢复 DHCP 失败");
            MessageBox.Show("操作失败！请以管理员权限运行。", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // ----------------- 配置读写 -----------------

    private void SaveCurrentConfig()
    {
        if (_cmbAdapters.SelectedIndex < 0)
        {
            return;
        }

        string adapterName = _adapters[_cmbAdapters.SelectedIndex].Name;
        AdapterProfile? profile = _config.Adapters.FirstOrDefault(a => a.AdapterName == adapterName);
        if (profile == null)
        {
            return;
        }

        profile.Profiles.Clear();
        foreach (DataGridViewRow row in _dgvProfiles.Rows)
        {
            if (row.IsNewRow)
            {
                continue;
            }

            profile.Profiles.Add(new IPConfig
            {
                ProfileName = row.Cells["ProfileName"].Value?.ToString() ?? "",
                IP = row.Cells["IP"].Value?.ToString() ?? "",
                SubnetMask = row.Cells["SubnetMask"].Value?.ToString() ?? "255.255.255.0",
                Gateway = row.Cells["Gateway"].Value?.ToString() ?? "",
                DNS1 = row.Cells["DNS1"].Value?.ToString() ?? "",
                DNS2 = row.Cells["DNS2"].Value?.ToString() ?? ""
            });
        }
    }

    private void LoadConfig()
    {
        if (!File.Exists(_configPath))
        {
            _config = new AppConfig();
            SaveConfig();
            return;
        }

        try
        {
            var serializer = new XmlSerializer(typeof(AppConfig));
            using var stream = new FileStream(_configPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            var loaded = serializer.Deserialize(stream) as AppConfig;
            _config = loaded ?? new AppConfig();
            _config.UiState ??= new UiState();
            _config.Adapters ??= new List<AdapterProfile>();
        }
        catch
        {
            _config = new AppConfig();
        }
    }

    private void SaveConfig()
    {
        try
        {
            _config.UiState ??= new UiState();
            var serializer = new XmlSerializer(typeof(AppConfig));
            using var stream = new FileStream(_configPath, FileMode.Create, FileAccess.Write, FileShare.None);
            serializer.Serialize(stream, _config);
        }
        catch (Exception ex)
        {
            MessageBox.Show("保存配置失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SetStatus(string text)
    {
        _lblStatus.Text = text;
        _lblStatus.ForeColor = text.StartsWith('✓')
            ? Color.Green
            : text.StartsWith('✗')
                ? Color.Red
                : Color.Gray;
    }
}
