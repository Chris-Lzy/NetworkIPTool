#nullable disable

namespace NetworkIPTool
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// 说明：所有尺寸均为 96 DPI 逻辑像素，运行时由 AutoScaleMode.Dpi 按实际缩放放大。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.root = new System.Windows.Forms.TableLayoutPanel();
            this.banner = new System.Windows.Forms.TableLayoutPanel();
            this.lblBrand = new System.Windows.Forms.Label();
            this.linkSite = new System.Windows.Forms.LinkLabel();
            this._lblVersion = new System.Windows.Forms.Label();
            this.toolbar = new System.Windows.Forms.TableLayoutPanel();
            this.lblAdapter = new System.Windows.Forms.Label();
            this._cmbAdapters = new System.Windows.Forms.ComboBox();
            this._btnRefresh = new System.Windows.Forms.Button();
            this._btnDhcp = new System.Windows.Forms.Button();
            this._btnRename = new System.Windows.Forms.Button();
            this._lblCurrentIp = new System.Windows.Forms.Label();
            this._dgvProfiles = new System.Windows.Forms.DataGridView();
            this.ProfileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubnetMask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gateway = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNS1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNS2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apply = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bottom = new System.Windows.Forms.TableLayoutPanel();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this._lblStatus = new System.Windows.Forms.Label();
            this._btnSave = new System.Windows.Forms.Button();
            this.root.SuspendLayout();
            this.banner.SuspendLayout();
            this.toolbar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dgvProfiles)).BeginInit();
            this.bottom.SuspendLayout();
            this.SuspendLayout();
            //
            // root —— 根布局：品牌栏 / 适配器卡片 / 表格 / 底栏
            //
            this.root.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.root.ColumnCount = 1;
            this.root.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.Controls.Add(this.banner, 0, 0);
            this.root.Controls.Add(this.toolbar, 0, 1);
            this.root.Controls.Add(this._dgvProfiles, 0, 2);
            this.root.Controls.Add(this.bottom, 0, 3);
            this.root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.root.Location = new System.Drawing.Point(0, 0);
            this.root.Margin = new System.Windows.Forms.Padding(0);
            this.root.Name = "root";
            this.root.RowCount = 4;
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.root.Size = new System.Drawing.Size(1100, 680);
            this.root.TabIndex = 0;
            //
            // banner —— 品牌栏（左：品牌 + 链接；右：版本 / 编译日期）
            //
            this.banner.AutoSize = true;
            this.banner.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.banner.BackColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this.banner.ColumnCount = 3;
            this.banner.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.banner.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.banner.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.banner.Controls.Add(this.lblBrand, 0, 0);
            this.banner.Controls.Add(this.linkSite, 1, 0);
            this.banner.Controls.Add(this._lblVersion, 2, 0);
            this.banner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.banner.Margin = new System.Windows.Forms.Padding(0);
            this.banner.Name = "banner";
            this.banner.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.banner.RowCount = 1;
            this.banner.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.banner.TabIndex = 0;
            //
            // lblBrand
            //
            this.lblBrand.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblBrand.AutoSize = true;
            this.lblBrand.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBrand.ForeColor = System.Drawing.Color.White;
            this.lblBrand.Margin = new System.Windows.Forms.Padding(0);
            this.lblBrand.Name = "lblBrand";
            this.lblBrand.TabIndex = 0;
            this.lblBrand.Text = "本软件来自 Loncoo   ";
            //
            // linkSite
            //
            this.linkSite.ActiveLinkColor = System.Drawing.Color.White;
            this.linkSite.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.linkSite.AutoSize = true;
            this.linkSite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkSite.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.5F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.linkSite.LinkColor = System.Drawing.Color.FromArgb(200, 230, 255);
            this.linkSite.Margin = new System.Windows.Forms.Padding(0);
            this.linkSite.Name = "linkSite";
            this.linkSite.TabIndex = 1;
            this.linkSite.TabStop = true;
            this.linkSite.Text = "loncoo.com";
            this.linkSite.VisitedLinkColor = System.Drawing.Color.FromArgb(200, 230, 255);
            this.linkSite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkSite_LinkClicked);
            //
            // _lblVersion —— 文本在运行时由 ApplyVersionInfo() 写入
            //
            this._lblVersion.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this._lblVersion.AutoSize = true;
            this._lblVersion.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this._lblVersion.ForeColor = System.Drawing.Color.FromArgb(220, 235, 250);
            this._lblVersion.Margin = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this._lblVersion.Name = "_lblVersion";
            this._lblVersion.TabIndex = 2;
            this._lblVersion.Text = "版本 V1.3.0";
            //
            // toolbar —— 适配器卡片
            //
            this.toolbar.AutoSize = true;
            this.toolbar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.toolbar.BackColor = System.Drawing.Color.White;
            this.toolbar.ColumnCount = 5;
            this.toolbar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.toolbar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.Controls.Add(this.lblAdapter, 0, 0);
            this.toolbar.Controls.Add(this._cmbAdapters, 1, 0);
            this.toolbar.Controls.Add(this._btnRefresh, 2, 0);
            this.toolbar.Controls.Add(this._btnDhcp, 3, 0);
            this.toolbar.Controls.Add(this._btnRename, 4, 0);
            this.toolbar.Controls.Add(this._lblCurrentIp, 1, 1);
            this.toolbar.SetColumnSpan(this._lblCurrentIp, 4);
            this.toolbar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolbar.Margin = new System.Windows.Forms.Padding(12, 12, 12, 0);
            this.toolbar.Name = "toolbar";
            this.toolbar.Padding = new System.Windows.Forms.Padding(12);
            this.toolbar.RowCount = 2;
            this.toolbar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.toolbar.TabIndex = 1;
            //
            // lblAdapter
            //
            this.lblAdapter.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblAdapter.AutoSize = true;
            this.lblAdapter.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.lblAdapter.Name = "lblAdapter";
            this.lblAdapter.TabIndex = 0;
            this.lblAdapter.Text = "适配器:";
            //
            // _cmbAdapters
            //
            this._cmbAdapters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this._cmbAdapters.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbAdapters.FormattingEnabled = true;
            this._cmbAdapters.Margin = new System.Windows.Forms.Padding(0);
            this._cmbAdapters.MinimumSize = new System.Drawing.Size(260, 0);
            this._cmbAdapters.Name = "_cmbAdapters";
            this._cmbAdapters.TabIndex = 1;
            this._cmbAdapters.SelectedIndexChanged += new System.EventHandler(this.CmbAdapters_SelectedIndexChanged);
            //
            // _btnRefresh —— 次要按钮：白底蓝边蓝字
            //
            this._btnRefresh.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnRefresh.AutoSize = true;
            this._btnRefresh.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._btnRefresh.BackColor = System.Drawing.Color.White;
            this._btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this._btnRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(214, 230, 245);
            this._btnRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(234, 242, 250);
            this._btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnRefresh.ForeColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this._btnRefresh.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this._btnRefresh.MinimumSize = new System.Drawing.Size(0, 32);
            this._btnRefresh.Name = "_btnRefresh";
            this._btnRefresh.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this._btnRefresh.TabIndex = 2;
            this._btnRefresh.Text = "刷新适配器";
            this._btnRefresh.UseVisualStyleBackColor = false;
            this._btnRefresh.Click += new System.EventHandler(this.BtnRefresh_Click);
            //
            // _btnDhcp —— 强调按钮：橙底白字 #E8A33D
            //
            this._btnDhcp.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnDhcp.AutoSize = true;
            this._btnDhcp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._btnDhcp.BackColor = System.Drawing.Color.FromArgb(232, 163, 61);
            this._btnDhcp.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnDhcp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(232, 163, 61);
            this._btnDhcp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(196, 130, 31);
            this._btnDhcp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(217, 146, 42);
            this._btnDhcp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnDhcp.ForeColor = System.Drawing.Color.White;
            this._btnDhcp.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this._btnDhcp.MinimumSize = new System.Drawing.Size(0, 32);
            this._btnDhcp.Name = "_btnDhcp";
            this._btnDhcp.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this._btnDhcp.TabIndex = 3;
            this._btnDhcp.Text = "恢复 DHCP";
            this._btnDhcp.UseVisualStyleBackColor = false;
            this._btnDhcp.Click += new System.EventHandler(this.BtnDhcp_Click);
            //
            // _btnRename —— 低频按钮：白底灰边灰字
            //
            this._btnRename.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnRename.AutoSize = true;
            this._btnRename.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._btnRename.BackColor = System.Drawing.Color.White;
            this._btnRename.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnRename.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(208, 215, 226);
            this._btnRename.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(226, 231, 238);
            this._btnRename.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(240, 243, 247);
            this._btnRename.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnRename.ForeColor = System.Drawing.Color.FromArgb(85, 85, 85);
            this._btnRename.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this._btnRename.MinimumSize = new System.Drawing.Size(0, 32);
            this._btnRename.Name = "_btnRename";
            this._btnRename.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this._btnRename.TabIndex = 4;
            this._btnRename.Text = "重命名适配器";
            this._btnRename.UseVisualStyleBackColor = false;
            this._btnRename.Click += new System.EventHandler(this.BtnRename_Click);
            //
            // _lblCurrentIp
            //
            this._lblCurrentIp.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._lblCurrentIp.AutoSize = true;
            this._lblCurrentIp.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this._lblCurrentIp.ForeColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this._lblCurrentIp.Margin = new System.Windows.Forms.Padding(0, 8, 0, 0);
            this._lblCurrentIp.Name = "_lblCurrentIp";
            this._lblCurrentIp.TabIndex = 5;
            this._lblCurrentIp.Text = "当前 IP: -";
            //
            // _dgvProfiles —— 配置表格
            //
            this._dgvProfiles.AllowUserToAddRows = false;
            this._dgvProfiles.AllowUserToDeleteRows = false;
            this._dgvProfiles.AllowUserToResizeRows = false;
            this._dgvProfiles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this._dgvProfiles.BackgroundColor = System.Drawing.Color.White;
            this._dgvProfiles.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this._dgvProfiles.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(46, 117, 182);
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(4, 8, 4, 8);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(46, 117, 182);
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this._dgvProfiles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this._dgvProfiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgvProfiles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProfileName,
            this.IP,
            this.SubnetMask,
            this.Gateway,
            this.DNS1,
            this.DNS2,
            this.Apply});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(6, 0, 6, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(220, 233, 247);
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this._dgvProfiles.DefaultCellStyle = dataGridViewCellStyle2;
            this._dgvProfiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dgvProfiles.EnableHeadersVisualStyles = false;
            this._dgvProfiles.GridColor = System.Drawing.Color.FromArgb(229, 233, 240);
            this._dgvProfiles.Margin = new System.Windows.Forms.Padding(12, 16, 12, 16);
            this._dgvProfiles.MultiSelect = false;
            this._dgvProfiles.Name = "_dgvProfiles";
            this._dgvProfiles.RowHeadersVisible = false;
            this._dgvProfiles.RowTemplate.Height = 34;
            this._dgvProfiles.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._dgvProfiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this._dgvProfiles.TabIndex = 2;
            this._dgvProfiles.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProfiles_CellClick);
            this._dgvProfiles.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DgvProfiles_CellFormatting);
            this._dgvProfiles.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProfiles_CellValueChanged);
            //
            // ProfileName —— 列宽比例 14
            //
            this.ProfileName.FillWeight = 14F;
            this.ProfileName.HeaderText = "配置名称";
            this.ProfileName.MinimumWidth = 80;
            this.ProfileName.Name = "ProfileName";
            //
            // IP —— 18
            //
            this.IP.FillWeight = 18F;
            this.IP.HeaderText = "IP 地址";
            this.IP.MinimumWidth = 100;
            this.IP.Name = "IP";
            //
            // SubnetMask —— 18
            //
            this.SubnetMask.FillWeight = 18F;
            this.SubnetMask.HeaderText = "子网掩码";
            this.SubnetMask.MinimumWidth = 100;
            this.SubnetMask.Name = "SubnetMask";
            //
            // Gateway —— 18
            //
            this.Gateway.FillWeight = 18F;
            this.Gateway.HeaderText = "默认网关";
            this.Gateway.MinimumWidth = 100;
            this.Gateway.Name = "Gateway";
            //
            // DNS1 —— 15
            //
            this.DNS1.FillWeight = 15F;
            this.DNS1.HeaderText = "首选 DNS";
            this.DNS1.MinimumWidth = 90;
            this.DNS1.Name = "DNS1";
            //
            // DNS2 —— 15
            //
            this.DNS2.FillWeight = 15F;
            this.DNS2.HeaderText = "备用 DNS";
            this.DNS2.MinimumWidth = 90;
            this.DNS2.Name = "DNS2";
            //
            // Apply —— 12，「应用此 IP」主按钮（蓝底白字；每行颜色由 CellFormatting 统一）
            //
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(46, 117, 182);
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(8, 4, 8, 4);
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(38, 95, 148);
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.Apply.DefaultCellStyle = dataGridViewCellStyle3;
            this.Apply.FillWeight = 12F;
            this.Apply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Apply.HeaderText = "操作";
            this.Apply.MinimumWidth = 90;
            this.Apply.Name = "Apply";
            this.Apply.Text = "应用此 IP";
            this.Apply.UseColumnTextForButtonValue = true;
            //
            // bottom —— 底栏：添加 / 删除 | 状态 | 保存
            //
            this.bottom.AutoSize = true;
            this.bottom.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bottom.BackColor = System.Drawing.Color.White;
            this.bottom.ColumnCount = 4;
            this.bottom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.bottom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.bottom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.bottom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));
            this.bottom.Controls.Add(this.btnAdd, 0, 0);
            this.bottom.Controls.Add(this.btnDel, 1, 0);
            this.bottom.Controls.Add(this._lblStatus, 2, 0);
            this.bottom.Controls.Add(this._btnSave, 3, 0);
            this.bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bottom.Margin = new System.Windows.Forms.Padding(0);
            this.bottom.Name = "bottom";
            this.bottom.Padding = new System.Windows.Forms.Padding(12, 8, 12, 8);
            this.bottom.RowCount = 1;
            this.bottom.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.bottom.TabIndex = 3;
            //
            // btnAdd —— 次要按钮
            //
            this.btnAdd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnAdd.AutoSize = true;
            this.btnAdd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this.btnAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(214, 230, 245);
            this.btnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(234, 242, 250);
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(0);
            this.btnAdd.MinimumSize = new System.Drawing.Size(0, 32);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "+ 添加配置";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.BtnAddProfile_Click);
            //
            // btnDel —— 次要按钮
            //
            this.btnDel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnDel.AutoSize = true;
            this.btnDel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnDel.BackColor = System.Drawing.Color.White;
            this.btnDel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this.btnDel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(214, 230, 245);
            this.btnDel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(234, 242, 250);
            this.btnDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDel.ForeColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this.btnDel.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnDel.MinimumSize = new System.Drawing.Size(0, 32);
            this.btnDel.Name = "btnDel";
            this.btnDel.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.btnDel.TabIndex = 1;
            this.btnDel.Text = "- 删除选中";
            this.btnDel.UseVisualStyleBackColor = false;
            this.btnDel.Click += new System.EventHandler(this.BtnDelProfile_Click);
            //
            // _lblStatus
            //
            this._lblStatus.AutoEllipsis = true;
            this._lblStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lblStatus.ForeColor = System.Drawing.Color.Gray;
            this._lblStatus.Margin = new System.Windows.Forms.Padding(16, 0, 8, 0);
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.TabIndex = 2;
            this._lblStatus.Text = "就绪";
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // _btnSave —— 主按钮：蓝底白字
            //
            this._btnSave.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnSave.AutoSize = true;
            this._btnSave.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._btnSave.BackColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this._btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(46, 117, 182);
            this._btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(31, 78, 121);
            this._btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(38, 95, 148);
            this._btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnSave.ForeColor = System.Drawing.Color.White;
            this._btnSave.Margin = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this._btnSave.MinimumSize = new System.Drawing.Size(0, 32);
            this._btnSave.Name = "_btnSave";
            this._btnSave.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this._btnSave.TabIndex = 3;
            this._btnSave.Text = "保存配置";
            this._btnSave.UseVisualStyleBackColor = false;
            this._btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            //
            // MainForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.ClientSize = new System.Drawing.Size(1100, 680);
            this.Controls.Add(this.root);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.MinimumSize = new System.Drawing.Size(1040, 639);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "网络适配器 IP 配置工具";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.root.ResumeLayout(false);
            this.root.PerformLayout();
            this.banner.ResumeLayout(false);
            this.banner.PerformLayout();
            this.toolbar.ResumeLayout(false);
            this.toolbar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dgvProfiles)).EndInit();
            this.bottom.ResumeLayout(false);
            this.bottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel root;
        private System.Windows.Forms.TableLayoutPanel banner;
        private System.Windows.Forms.Label lblBrand;
        private System.Windows.Forms.LinkLabel linkSite;
        private System.Windows.Forms.Label _lblVersion;
        private System.Windows.Forms.TableLayoutPanel toolbar;
        private System.Windows.Forms.Label lblAdapter;
        private System.Windows.Forms.ComboBox _cmbAdapters;
        private System.Windows.Forms.Button _btnRefresh;
        private System.Windows.Forms.Button _btnDhcp;
        private System.Windows.Forms.Button _btnRename;
        private System.Windows.Forms.Label _lblCurrentIp;
        private System.Windows.Forms.DataGridView _dgvProfiles;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProfileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn IP;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubnetMask;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gateway;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNS1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNS2;
        private System.Windows.Forms.DataGridViewButtonColumn Apply;
        private System.Windows.Forms.TableLayoutPanel bottom;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Label _lblStatus;
        private System.Windows.Forms.Button _btnSave;
    }
}
