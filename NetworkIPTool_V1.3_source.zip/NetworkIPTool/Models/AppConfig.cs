namespace NetworkIPTool.Models;

/// <summary>
/// 根配置。Adapters 与 V1.01 兼容；UiState 为 V1.1 新增，缺失时使用默认。
/// </summary>
public class AppConfig
{
    public List<AdapterProfile> Adapters { get; set; } = new();

    /// <summary>界面状态（窗口位置/大小、上次选中的适配器等）。</summary>
    public UiState UiState { get; set; } = new();
}
