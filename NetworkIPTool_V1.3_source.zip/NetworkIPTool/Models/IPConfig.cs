namespace NetworkIPTool.Models;

/// <summary>
/// 一套 IP 配置（名称、地址、掩码、网关、DNS）。
/// XML 字段与 V1.01 的 ip_config.xml 兼容。
/// </summary>
public class IPConfig
{
    public string ProfileName { get; set; } = "Profile";

    public string IP { get; set; } = "";

    public string SubnetMask { get; set; } = "255.255.255.0";

    public string Gateway { get; set; } = "";

    public string DNS1 { get; set; } = "";

    public string DNS2 { get; set; } = "";
}
