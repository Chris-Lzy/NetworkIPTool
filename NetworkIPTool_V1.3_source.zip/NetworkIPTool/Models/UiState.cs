namespace NetworkIPTool.Models;

/// <summary>
/// 上次退出时的界面状态。旧版配置文件没有此节点时使用默认值。
/// </summary>
public class UiState
{
    /// <summary>界面布局版本（V1.3 起写入 "1.3"）。与当前版本不一致时忽略保存的窗口尺寸 / 位置。</summary>
    public string Version { get; set; } = "";

    /// <summary>保存时窗口所在显示器的 DPI（96 = 100%）。与当前 DPI 不一致时忽略保存的尺寸。</summary>
    public int WindowDpi { get; set; } = 0;

    /// <summary>窗口左边距（屏幕坐标）。</summary>
    public int WindowX { get; set; } = -1;

    /// <summary>窗口上边距（屏幕坐标）。</summary>
    public int WindowY { get; set; } = -1;

    /// <summary>窗口宽度（物理像素）。0 表示使用默认尺寸（1024 逻辑像素 × 当前缩放）。</summary>
    public int WindowWidth { get; set; } = 0;

    /// <summary>窗口高度（物理像素）。0 表示使用默认尺寸（620 逻辑像素 × 当前缩放）。</summary>
    public int WindowHeight { get; set; } = 0;

    /// <summary>窗口状态：Normal / Maximized（Minimized 会按 Normal 还原）。</summary>
    public string WindowState { get; set; } = "Normal";

    /// <summary>上次选中的适配器名称（不含状态后缀）。</summary>
    public string LastAdapterName { get; set; } = "";

    /// <summary>上次选中的配置行索引（无效时忽略）。</summary>
    public int LastProfileRowIndex { get; set; } = -1;
}
