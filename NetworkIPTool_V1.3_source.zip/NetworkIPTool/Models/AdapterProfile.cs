namespace NetworkIPTool.Models;

/// <summary>
/// 单个网卡下保存的多套 IP 配置。
/// </summary>
public class AdapterProfile
{
    public string AdapterName { get; set; } = "";

    public List<IPConfig> Profiles { get; set; } = new();
}
