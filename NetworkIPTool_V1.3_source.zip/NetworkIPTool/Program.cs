using System;
using System.Windows.Forms;

namespace NetworkIPTool;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        // 必须在创建任何窗口之前调用；与 app.manifest / csproj 中的 PerMonitorV2 保持一致
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
