# 网络适配器 IP 配置工具 (NetworkIPTool) v1.3

Windows 网卡 IP 配置小工具：为每个适配器保存多套静态 IP（掩码 / 网关 / DNS），一键应用或恢复 DHCP，支持重命名网卡。

本仓库为 **V1.01 丢失源码后的干净重写**，并新增「记住上次界面」功能。`ip_config.xml` 与 V1.01 **完全兼容**（旧文件可直接沿用；新版本会追加 `UiState` 节点）。

## 功能一览

- 列出本机网卡（WMI `Win32_NetworkAdapter`，已连接 / 已断开）
- 每张网卡多套 IP 配置表：配置名称、IP、子网掩码、默认网关、首选/备用 DNS
- 「应用此 IP」一键设置静态地址（`netsh`）
- 「恢复 DHCP」
- 「重命名适配器」
- 配置持久化到程序目录下的 `ip_config.xml`
- 标题栏与品牌栏右侧显示 **版本号与编译日期**（编译时自动写入）
- **新功能：记住上次界面** — 退出时保存窗口位置/大小/最大化状态、上次选中的适配器与配置行；下次打开自动还原

## 环境要求

- Windows 10 / 11（需管理员权限，清单已声明 `requireAdministrator`）
- 编译：[.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)（建议 Visual Studio 2022 17.8+，并勾选「.NET 桌面开发」工作负载）
- 运行：[.NET 8 桌面运行时（Desktop Runtime x64）](https://dotnet.microsoft.com/download/dotnet/8.0)。V1.3 起目标框架由已停止支持的 net6.0 升级为 net8.0

> 设置 IP / DHCP / 重命名必须提升权限。本版通过 `app.manifest` 的 `requireAdministrator` 在启动时请求管理员，不再依赖无效的 `Verb=runas` + `UseShellExecute=false` 组合。

## 如何打开与编译

1. 用 Visual Studio 2022 打开 `NetworkIPTool.csproj`
2. 目标框架为 `net8.0-windows`；`MainForm` / `RenameDialog` 均为标准「窗体 + Designer.cs + resx」，可在 VS 窗体设计器中直接打开编辑
3. 生成 → 生成解决方案（或 `Ctrl+Shift+B`）
4. 输出目录会得到 `NetworkIPTool.exe`，并复制 `ip_config.xml`（含你原先的「本体网口」等配置）

命令行：

```bat
dotnet restore
dotnet build -c Release
```

发布单文件示例：

```bat
dotnet publish -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true
```

## 配置文件

路径：与 `NetworkIPTool.exe` 同目录的 `ip_config.xml`。

- `Adapters` / `AdapterProfile` / `IPConfig`：与 V1.01 相同，可直接迁移旧文件
- `UiState`（V1.1 新增，缺失时用默认值；V1.3 新增 `Version` / `WindowDpi`，与当前版本或 DPI 不一致、或尺寸小于最小值时忽略保存的窗口尺寸）：
  - `WindowX` / `WindowY` / `WindowWidth` / `WindowHeight`
  - `WindowState`：`Normal` 或 `Maximized`（若上次是最小化，下次按 Normal 打开）
  - `LastAdapterName`：上次选中的适配器名称
  - `LastProfileRowIndex`：上次选中的配置行

新适配器首次出现时会自动创建 5 条空配置（默认掩码 `255.255.255.0`）。

## 项目结构

```
NetworkIPTool/
├── NetworkIPTool.csproj
├── Program.cs
├── MainForm.cs            # 业务逻辑与事件处理（partial）
├── MainForm.Designer.cs   # InitializeComponent：控件、布局、事件绑定
├── MainForm.resx
├── RenameDialog.cs
├── RenameDialog.Designer.cs
├── RenameDialog.resx
├── NetworkService.cs      # WMI / netsh / 当前 IP
├── Models/
│   ├── AppConfig.cs
│   ├── AdapterProfile.cs
│   ├── IPConfig.cs
│   └── UiState.cs
├── ip_config.xml          # 示例配置（复制到输出目录）
├── app.ico
├── app.manifest           # requireAdministrator + PerMonitorV2
├── LAYOUT_FIX.md          # V1.2 / V1.3 布局、高 DPI 与更新说明
└── README.md
```

## 相对 V1.01 的改动摘要

| 项 | 说明 |
|----|------|
| 源码结构 | 拆分为 Models / NetworkService / 窗体，去掉 ILSpy 反编译噪音 |
| 管理员提权 | 清单 `requireAdministrator`；`netsh` 仅重定向输出，不再错误地设 `Verb=runas` |
| 枚举/属性 | 使用 `FormStartPosition.CenterScreen`、`ComboBoxStyle.DropDownList` 等正确枚举 |
| 界面记忆 | 退出时写入 `UiState`，启动时还原窗口与选中项 |
| 高 DPI（V1.2） | PerMonitorV2 + `AutoScaleMode.Dpi`；TableLayoutPanel/FlowLayoutPanel 自适应布局，按钮 AutoSize，详见 `LAYOUT_FIX.md` |
| 视觉（V1.2） | 主色 #2E75B6、强调色 #E8A33D、背景 #F5F7FA；按钮主/次/弱三级层次 |
| V1.3 | 默认窗口尺寸按 DPI 正确计算（7 列无横向滚动）；「应用此 IP」每行同色；显示版本号 + 编译日期；拆分为标准 Designer 窗体；目标框架 net8.0-windows |
| 版本号 | 1.3.0 |

## 许可 / 品牌

界面保留 Loncoo 品牌条与链接 [loncoo.com](https://loncoo.com)。
