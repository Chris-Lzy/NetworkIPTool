# NetworkIPTool V1.2 / V1.3 布局 / 高 DPI 修复说明（LAYOUT_FIX）

> 版本：1.1.0 → **1.2.0**　技术栈：.NET 6 WinForms（纯代码建窗体，无 Designer.cs）
> 改动范围：仅布局与外观属性（Size / AutoSize / AutoSizeMode / Padding / Margin / Anchor / Dock / Font / AutoScaleMode / 列宽 / 颜色），以及用 TableLayoutPanel / FlowLayoutPanel 替换绝对坐标。
> **业务逻辑、控件字段名、事件处理函数、调用顺序均未改动**；未引入第三方库；没有手写 Resize 事件。
> 编译验证：Linux 上用 .NET SDK 8.0.427 执行 `dotnet build -p:EnableWindowsTargeting=true` → **Build succeeded，0 个错误**（仅 1 条 NETSDK1138「net6.0 已停止支持」提示）。**实际显示效果仍需在 Windows 上截图确认**。

---

## 〇、V1.3 更新说明（2026-11-09）

> 版本 1.2.0 → **1.3.0**。根据 V1.2 实机截图反馈修正 4 个问题。
> 编译验证：`dotnet build -p:EnableWindowsTargeting=true` → **0 错误 0 警告**；`dotnet publish -c Release -r win-x64 --self-contained false` → 成功，exe 内已含图标、版本信息、管理员 + PerMonitorV2 清单（用 pefile 检查过）。
> **目标框架由 net6.0-windows 升级为 net8.0-windows**（.NET 6 已于 2024-11 停止支持）。运行需要「.NET 8 桌面运行时 x64」。
> 与 V1.2 的完整差异见 `NetworkIPTool_V1.3.diff`。

### 1. 初始窗体大小不对（启动时太小、出现横向滚动条、「备用 DNS」「操作」列被截、只看到约 4 行、下拉框文字被截）

**原因**
- V1.2 在构造函数里依赖 WinForms 的 AutoScale 去放大窗体自身的 `Size` / `MinimumSize`，再用 `ApplyUiStateWindow()` 根据保存的尺寸夹紧。截图 1 中字体和列最小宽（用 `LogicalToDeviceUnits` 单独换算）已经放大，但窗体仍接近 100% 时的 1024×620 物理像素，说明**窗体尺寸那一次缩放没有生效**。这次缩放发生在句柄创建前，用的是系统 DPI；另外 `ip_config.xml` 里还留着旧版按物理像素保存的 960×620 等尺寸，也会被沿用。
- V1.2 列最小宽之和为 716 逻辑 px（150% 时 1074 物理 px），比没有被放大的窗体还宽，所以出现横向滚动条，右边两列被挤出可视区。
- 默认客户区 1024×620 本身偏紧：150% 时扣掉标题栏、品牌栏、卡片、底栏后，表格只剩约 4 行。

**修改**
- 窗口尺寸不再依赖 AutoScale：`ApplyUiStateWindow()` 改到 **`Load` 事件**里执行。这时句柄已创建，`DeviceDpi` 就是窗口实际所在显示器的 DPI。直接用 `SizeFromClientSize(LogicalToDeviceUnits(...))` 算出**物理像素**并赋值，无论之前有没有自动缩放，结果都只缩放一次。
- 默认客户区改为 **1100×680 逻辑 px**（150% 时 1650×1020，超出工作区会自动收紧）。最小客户区仍为 1024×600 逻辑 px，同样换算后再夹紧到工作区。
- `UiState` 新增 `Version`（当前为 "1.3"）和 `WindowDpi`。**版本不一致、DPI 不一致、或保存的尺寸小于最小尺寸时，忽略保存的尺寸和位置**，改用默认尺寸并在当前屏幕居中。选中的适配器和配置行照常还原。
- 列最小宽下调为 80/100/100/100/90/90/90（合计 **650** 逻辑 px）。最小窗口下表格可用宽约 1024−24−2−17≈981，比列宽总和多出 331，不会再出现横向滚动；同时设置 `ScrollBars = Vertical`。
- 下拉框最小宽从 220 加到 260。
- 新增 `DpiChanged` 处理：窗口拖到不同缩放的显示器时，重新换算表格行高、列最小宽和单元格 Padding（V1.2 的已知限制已消除）。
- 高度核算（逻辑 px）：品牌栏约 35 + 卡片约 97 + 表格上下外边距 32 + 底栏 48 ≈ 212。默认 680 时表格约 468：表头 37 + 约 12 行×34；最小 600 时约 10 行；1366×768 @150% 被夹紧到工作区（约 485 逻辑 px 高）时，表头 + 约 6 行。

### 2. 第 2、4 行的「应用此 IP」按钮看不见（白字落在浅色底上）

**原因**：DataGridView 的样式优先级是 单元格 Style > 行 DefaultCellStyle > **AlternatingRowsDefaultCellStyle** > 列 DefaultCellStyle > 表格 DefaultCellStyle。V1.2 设置了隔行浅色 `AlternatingRowsDefaultCellStyle.BackColor = #F9FBFD`，它的优先级**高于** Apply 列的 `DefaultCellStyle.BackColor = #2E75B6`。所以偶数行按钮底色被换成近白色，白字就看不见了。

**修改**：
- 删除 `AlternatingRowsDefaultCellStyle`。
- 新增 `DgvProfiles_CellFormatting`（只改显示用的 `e.CellStyle`，不碰数据）：Apply 列每一行都强制为蓝底 #2E75B6、白字，选中行为深蓝 #265F94；其它列在偶数行画浅色隔行底 #F9FBFD。
- 即使这个事件没有触发，按钮列也只会沿用列样式的蓝色，不会再变白。

### 3. 没有编译日期和版本号

**修改**
- csproj：`Version / AssemblyVersion / FileVersion / InformationalVersion = 1.3.0`，`AssemblyTitle / Product = 网络适配器 IP 配置工具`，`Company = Loncoo`，`Copyright © 2026 Loncoo`，`IncludeSourceRevisionInInformationalVersion=false`，避免版本号后面带「+提交号」。
- 编译时写入编译日期：`<AssemblyMetadata Include="BuildDate" Value="$([System.DateTime]::Now.ToString('yyyy-MM-dd HH:mm'))" />`，用的是编译机本地时间。
- 运行时由 `ApplyVersionInfo()` 通过反射读取 `AssemblyInformationalVersionAttribute` 和 `AssemblyMetadataAttribute("BuildDate")`：
  - 标题栏：`网络适配器 IP 配置工具 V1.3.0`
  - 品牌栏右侧（新增 `_lblVersion`）：`版本 V1.3.0  编译日期 2026-11-09 22:20`（示例）
- 资源管理器 → 属性 → 详细信息能看到文件版本 1.3.0.0、产品版本 1.3.0、公司 Loncoo、版权和文件说明（已在发布出的 exe 上确认）。

### 4. 源代码没有 Form 窗体代码（无法在 VS 设计器中打开）

**修改**：拆分为标准 Visual Studio WinForms 结构。
| 文件 | 内容 |
|------|------|
| `MainForm.cs` | `partial class MainForm`：业务字段、构造函数（`InitializeComponent()` 之后只做运行时相关的：版本文字、DPI 换算、读配置）、全部业务方法和事件处理（原样保留） |
| `MainForm.Designer.cs` | `InitializeComponent()`：全部控件、TableLayoutPanel、列、单元格样式、颜色字体、事件绑定；`components` 字段和 `Dispose` 重写；控件字段声明在文件末尾 |
| `MainForm.resx` | 设计器资源（列的 UserAddedColumn 元数据） |
| `RenameDialog.cs` / `.Designer.cs` / `.resx` | 同上；原来「确定」按钮上的 lambda 改为命名方法 `BtnOk_Click`，逻辑不变 |

- Designer 代码只用设计器能识别的写法：`SuspendLayout / ResumeLayout`、`BeginInit / EndInit`、`new Font(...)`、`Color.FromArgb(...)`，没有 lambda、循环或辅助方法调用；`AutoScaleDimensions = new SizeF(96F, 96F)` 与 `AutoScaleMode.Dpi` 保持一致。
- 品牌链接原来的 lambda 改为命名方法 `LinkSite_LinkClicked`，打开 https://loncoo.com 的逻辑不变。
- 所有控件字段名、事件处理方法名、业务逻辑不变。表格列字段名就是列的 `Name`（`ProfileName / IP / SubnetMask / Gateway / DNS1 / DNS2 / Apply`），所以 `Cells["IP"]`、`Columns[..].Name == "Apply"` 这些写法继续有效。
- SDK 风格项目会自动把 `*.Designer.cs`、`*.resx` 挂到同名窗体下面，不需要手写 `DependentUpon`。
- 新增的控件 / 方法只有：`_lblVersion`、`ApplyVersionInfo`、`ScaleGridMetrics`、`MainForm_DpiChanged`、`DgvProfiles_CellFormatting`、`MainForm_Load`（原构造函数里的 Load lambda 改成命名方法，调用顺序还是 `LoadConfig → ApplyUiStateWindow → RefreshAdapters`）。

### V1.3 自检清单

| 项目 | 状态 |
|------|------|
| 编译（net8.0-windows，EnableWindowsTargeting） | ✅ 0 错误 0 警告 |
| 发布 win-x64（依赖框架） | ✅ exe 含图标 / 版本 / 清单 |
| 默认尺寸下 7 列无横向滚动，可见 ≥ 6 行 | ✅ 计算满足；⏳ 需 Windows 截图确认（100% / 125% / 150%） |
| 第 2、4 行「应用此 IP」与第 1、3 行同色 | ✅ 代码保证；⏳ 需截图确认 |
| 标题栏和品牌栏显示版本 + 编译日期 | ✅；⏳ 需截图确认 |
| VS 设计器可打开 MainForm / RenameDialog | ✅ 结构符合；⏳ 需在 VS2022 实际打开确认（这边是 Linux，没有设计器） |
| 8 项锁定功能 | ✅ 全部保留，见第六节；第 1 项标题现在附带版本号，这是用户要求 |

---

> 以下第一～七节为 V1.2 原始说明（V1.3 中被替换的数值以第〇节为准：默认客户区 1100×680、列最小宽 80/100/100/100/90/90/90、下拉框最小宽 260、表格横向滚动条关闭、取消 AlternatingRowsDefaultCellStyle）。

## 一、逐条原因分析（现象 → 具体属性）

### 总根因（贯穿 1~5）
V1.1 窗体用代码手写，**从未设置 `AutoScaleMode` / `AutoScaleDimensions`，也没有用 `SuspendLayout/ResumeLayout` 包住控件创建**，所以 WinForms 根本不做 DPI 缩放；而 `Program.cs` 是 `HighDpiMode.SystemAware`，字体（以 pt 定义）会随系统 DPI 变大。结果是：**字体放大了 1.25/1.5 倍，但所有 `Location` / `Size` 仍是 96 DPI 下写死的像素值**——容器没变大、内容变大了，于是处处裁剪和重叠。

| # | 现象 | 原因（对应到属性） | V1.2 修复 |
|---|------|------------------|-----------|
| 1 | 按钮文字被裁：刷新适配器→「刷新适」、恢复 DHCP→「恢复」、重命名适配器→「重命名话」、保存配置→「保存配」、+ 添加配置→「+ 添加」、- 删除选中→「- 删除选」 | `AutoSize=false`（默认）+ `Size=new Size(100,28)` / `(110,28)` 写死；150% 时「保存配置」需要 72px 文字 + 内边距，而按钮仍是 100px 物理像素，且 Flat 按钮自带边框/内距，显示不下第 4 个字。「重命名适配器」6 字需 108px 文字，110px 宽完全不够 | 所有按钮 `AutoSize=true` + `AutoSizeMode=GrowAndShrink` + `Padding(12,0,12,0)` + `MinimumSize(0,32)`，宽度由文字决定，恒 ≥ 文字宽 + 24px |
| 2 | 按钮文字上下贴边 | `Height=28` 写死，150% 时 9pt 雅黑行高 ≈ 31px > 28px | 高度改为 `MinimumSize.Height=32`（逻辑），随 DPI 缩放为 40/48px；`TextAlign=MiddleCenter` |
| 3 | 表格列宽不合理；「操作」按钮贴右边 | `FillWeight` 为 12/18/18/18/16/16/10，没有 `MinimumWidth`；`Apply` 列单元格 `Padding` 为 0，按钮铺满单元格；表格 `Dock=Fill` 直接贴窗体边，无外边距 | `FillWeight` 精确改为 **14/18/18/18/15/15/12**；每列设 `MinimumWidth`（按 DPI 换算）；`Apply` 列 `DefaultCellStyle.Padding=(8,4,8,4)`；表格 `Margin=(12,16,12,16)` 放进根 TableLayoutPanel |
| 4 | 顶部控件行与表格太近；「当前 IP」压住表头；「适配器:」压住下拉框；loncoo.com 被前面文字盖住 | toolbar `Height=70` 写死，`_lblCurrentIp.Location=(75,40)` 字体放大后底边超出 70 → 盖到表格；`lblAdapter` 在 x=10 而 `_cmbAdapters` 写死 x=75，标签放大后宽度 > 65px 就压上去；`linkSite.Location=(175,9)` 写死，`lblBrand` 放大后宽度 > 160px 就覆盖链接；banner `Height=35` 写死 | toolbar 改为 `TableLayoutPanel`（AutoSize），列：`AutoSize | 100% | AutoSize×3`，第二行放当前 IP；banner 改为 `FlowLayoutPanel`（AutoSize），标签与链接顺序排列，绝不重叠；表格上方固定 16px 区块间距 |
| 5 | 高 DPI 整体裁剪 / 错位 | `HighDpiMode.SystemAware`，manifest 无 DPI 声明；Form 无 `AutoScaleMode`；`Size(960,620)`、`MinimumSize(800,500)` 是物理像素；`RowTemplate.Height`、单元格 Padding 不随 DPI | `SetHighDpiMode(PerMonitorV2)` + manifest `dpiAwareness=PerMonitorV2` + csproj `ApplicationHighDpiMode`；Form `AutoScaleDimensions=96×96`、`AutoScaleMode=Dpi`，构造函数整体包在 `SuspendLayout()/ResumeLayout(false)+PerformLayout()` 中，在 ResumeLayout 时一次性把所有 Size/Margin/Padding/MinimumSize 从 96DPI 逻辑值放大；DataGridView 不参与 AutoScale 的行高、列最小宽、单元格 Padding 用 `LogicalToDeviceUnits()` 换算 |

补充：
- **窗口状态还原**：`ApplyUiStateWindow()` 移到 `ResumeLayout` 之后执行，保存的物理像素尺寸不会被二次缩放；并且把 `MinimumSize`、窗口宽高、位置都**收紧到目标屏幕工作区**内（1366×768 @150% 时逻辑工作区只有约 910×485，1024×600 的最小尺寸会被压到工作区大小，不会出屏）。
- `UiState.WindowWidth/Height` 默认值由 960/620 改为 0（=使用「1024×620 逻辑 × 当前缩放」的默认尺寸）；旧配置文件里已保存的值照常使用。

---

## 二、【布局方案说明】

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ① 品牌栏 banner  FlowLayoutPanel  AutoSize  背景 #2E75B6  Padding 12,8   │
│   本软件来自 Loncoo   loncoo.com                       （10.5pt ≈ 14px）  │
├──────────────────────────────────────────────────────────────────────────┤  ↕12
│  ② 适配器卡片 toolbar  TableLayoutPanel  AutoSize  白底  Padding 12       │
│  ┌──────┬──────────────────────────────┬────────┬────────┬──────────┐    │
│  │适配器:│ [ 以太网 [已连接]          ▼] │刷新适配器│恢复 DHCP│重命名适配器│    │
│  │      │ 当前 IP: 192.168.1.10（蓝色粗体，跨 4 列）                 │    │
│  └──────┴──────────────────────────────┴────────┴────────┴──────────┘    │
│     Auto      100%（随窗口拉伸）            Auto     Auto      Auto        │
├──────────────────────────────────────────────────────────────────────────┤  ↕16
│  ③ 配置表格 _dgvProfiles  Dock=Fill（根 TLP 第 3 行 100%）Margin 12,16     │
│  ┌─────────┬───────────┬───────────┬───────────┬─────────┬─────────┬────────┐│
│  │配置名称14│ IP 地址 18 │ 子网掩码 18│ 默认网关 18│首选DNS 15│备用DNS 15│ 操作 12 ││
│  ├─────────┼───────────┼───────────┼───────────┼─────────┼─────────┼────────┤│
│  │配置 1   │           │255.255.255.0│         │         │         │[应用此IP]││
│  └─────────┴───────────┴───────────┴───────────┴─────────┴─────────┴────────┘│
├──────────────────────────────────────────────────────────────────────────┤  ↕16
│ ④ 底栏 bottom  TableLayoutPanel AutoSize 白底 Padding 12,8                │
│ [+ 添加配置] [- 删除选中]  就绪（状态，100% 宽，过长省略号…）  [保存配置]  │
└──────────────────────────────────────────────────────────────────────────┘
根容器 root：TableLayoutPanel Dock=Fill，1 列 4 行（Auto / Auto / 100% / Auto），背景 #F5F7FA
```

设计理由：
1. **三区分层**：上 = 「选哪块网卡、它现在是什么 IP、对网卡的操作」，中 = 「多套 IP 配置」，下 = 「对配置表的增删存 + 状态」。操作按钮紧贴它所作用的对象，扫视路径从上到下一次完成。
2. **全部改为流式容器**：每个单元格的尺寸由内容的 PreferredSize 决定，DPI、字体、文字长度变化时自动重排，不再有任何绝对坐标，因此不可能再出现重叠。
3. **视觉层次**（只改外观，不改逻辑）：
   - 主操作（实心蓝 #2E75B6）：表格内「应用此 IP」、底栏「保存配置」（放在最右，符合确认类按钮习惯）
   - 强调（实心橙 #E8A33D）：「恢复 DHCP」——会改变网卡状态，用强调色提醒
   - 次要（白底蓝边蓝字）：「刷新适配器」「+ 添加配置」「- 删除选中」
   - 低频（白底灰边灰字）：「重命名适配器」
   - 全部 `FlatStyle.Flat`，用 `FlatAppearance.BorderColor / MouseOverBackColor / MouseDownBackColor` 提供悬停 / 按下反馈；未做圆角（需要自绘，风险大于收益），未加禁用态（避免影响逻辑）。
4. 底栏控件顺序调整为「添加、删除 | 状态 | 保存」，只是视觉位置变化，三个按钮的字段名与 `Click` 处理函数完全不变。
5. 红线遵守：没有删除 / 合并 / 隐藏任何按钮，没有菜单 / 折叠面板，7 列全部保留，未使用纯图标按钮。

---

## 三、【控件尺寸与间距规范表】（布局规范表）

所有数值为 **96 DPI 逻辑像素**；125% / 150% 时由 `AutoScaleMode.Dpi` 自动 ×1.25 / ×1.5（DataGridView 内部值由 `LogicalToDeviceUnits` 换算）。

| 项目 | 规范值（逻辑 px） | 100% | 125% | 150% | 实现属性 |
|------|----------------|------|------|------|---------|
| 正文 / 按钮 / 表头字体 | Microsoft YaHei UI 9pt（=12px），表头粗体 | 12px | 15px | 18px | `Font` |
| 品牌栏字体 | 10.5pt（=14px） | 14 | 17.5 | 21 | `Font` |
| 主色 / 强调 / 背景 / 文字 | #2E75B6 / #E8A33D / #F5F7FA / #333333 | — | — | — | `BackColor` / `ForeColor` |
| 按钮高度 | ≥ 32 | 32 | 40 | 48 | `MinimumSize.Height` + `AutoSize` |
| 按钮宽度 | 文字宽 + 24（左右 Padding 各 12） | 自动 | 自动 | 自动 | `AutoSize=true`、`AutoSizeMode=GrowAndShrink`、`Padding(12,0,12,0)` |
| 按钮间距 | 8 | 8 | 10 | 12 | `Margin.Left=8` |
| 容器内边距 | 12 | 12 | 15 | 18 | `Padding` |
| 区块间距 | 16（卡片顶部距品牌栏 12） | 16 | 20 | 24 | `Margin` |
| 品牌栏 | Padding 12,8；高度自动 ≈ 35 | ≈35 | ≈44 | ≈53 | `FlowLayoutPanel.AutoSize` |
| 适配器下拉框 | 最小宽 220，其余随窗口拉伸 | ≥220 | ≥275 | ≥330 | `MinimumSize`、`Anchor=Left|Right`、列 `Percent 100` |
| 「当前 IP」与上一行间距 | 8 | 8 | 10 | 12 | `Margin.Top` |
| 表格行高 | 34 | 34 | 43 | 51 | `RowTemplate.Height = LogicalToDeviceUnits(34)` |
| 表头高度 | 自动（字体 + 上下 8） | ≈37 | ≈46 | ≈55 | `ColumnHeadersHeightSizeMode=AutoSize` + 表头 `Padding` |
| 表格列比例 / 最小宽 | 配置名称 14 / 90；IP 18 / 110；掩码 18 / 110；网关 18 / 110；首选 DNS 15 / 100；备用 DNS 15 / 100；操作 12 / 96 | — | — | ×1.5 | `FillWeight`、`MinimumWidth` |
| 「应用此 IP」按钮内缩 | 左右 8、上下 4 | 8/4 | 10/5 | 12/6 | `Apply.DefaultCellStyle.Padding` |
| 网格线 / 隔行底色 / 选中色 | #E5E9F0 / #F9FBFD / #DCE9F7 | — | — | — | `GridColor`、`AlternatingRowsDefaultCellStyle` |
| 窗口默认 / 最小 | 1024×620 / 1024×600 | 1024×620 | 1280×775 | 1536×930 → 收紧到工作区 | `Size`、`MinimumSize` + `ApplyUiStateWindow` 夹紧 |
| 重命名对话框 | 自动大小；输入框最小 280；按钮最小 80×32 | 自动 | 自动 | 自动 | `Form.AutoSize`、`TableLayoutPanel` |
| 缩放策略 | PerMonitorV2 + `AutoScaleMode.Dpi` + `AutoScaleDimensions(96,96)`；字体用 pt 自然随 DPI；跨显示器移动时 WinForms 按新 DPI 重新缩放 | | | | `Program.cs`、`app.manifest`、`.csproj` |

最小可用宽度核算（逻辑 px）：
- 表格列最小宽之和 = 90 + 110×3 + 100×2 + 96 = **716**，加左右外边距 24 + 边框 ≈ 742。
- 工具栏最小宽 ≈ 12 + 41（适配器:）+ 8 + 220 + (8+84) + (8+83) + (8+96) + 12 + 卡片外边距 24 ≈ **604**。
- 1366×768 @150% 的逻辑工作区约 **910×485**，两者都放得下；高度方面固定区块约 35 + 96 + 32 + 48 ≈ 211，表格还剩约 270 逻辑 px（表头 + 约 6 行），超出部分出现滚动条，不会裁剪。

---

## 四、控件宽度计算依据

公式：**中文宽度 ≈ 字号(px) × 字数 + 2 × 水平内边距**
- 9pt 微软雅黑：100% = 12px、125% = 15px、150% = 18px；内边距 12px 逻辑 → 12 / 15 / 18px（两侧合计 24 / 30 / 36）。
- 英文、数字、符号按约 0.5~0.65 个汉字宽估算：`DHCP` ≈ 2.6 字、`IP` ≈ 0.9 字、空格 ≈ 0.3 字、`+ ` / `- ` ≈ 0.9 字。
- 另有 Flat 边框 1px×2，AutoSize 已自动计入。

| 按钮 | 折算字数 | 文字宽 100% / 125% / 150% | + 2×内边距后最小宽 100% / 125% / 150% | V1.1 写死宽度（物理 px） | 结论 |
|------|---------|--------------------------|--------------------------------------|----------------------|------|
| 刷新适配器 | 5 | 60 / 75 / 90 | **84 / 105 / 126** | 100 | 150% 不足 → 原「刷新适」 |
| 恢复 DHCP | 2 + 0.3 + 2.6 ≈ 4.9 | 59 / 74 / 88 | **83 / 104 / 124** | 100 | 125%/150% 不足 → 原「恢复」 |
| 重命名适配器 | 6 | 72 / 90 / 108 | **96 / 120 / 144** | 110 | 125% 起不足 → 原「重命名话」 |
| 保存配置 | 4 | 48 / 60 / 72 | **72 / 90 / 108** | 100 | 150% 不足 → 原「保存配」 |
| + 添加配置 | 0.9 + 4 ≈ 4.9 | 59 / 74 / 88 | **83 / 104 / 124** | 100 | 125%/150% 不足 → 原「+ 添加」 |
| - 删除选中 | 0.9 + 4 ≈ 4.9 | 59 / 74 / 88 | **83 / 104 / 124** | 100 | 同上 |
| 应用此 IP（表格按钮） | 3 + 0.3 + 0.9 ≈ 4.2 | 50 / 63 / 76 | 文字 + 单元格内缩 2×8 + 按钮自身 ≈ 74 → **列最小宽取 96 / 120 / 144** | 列宽 10% 无下限 | 改为 12% 且有最小宽 |
| 确定 / 取消（对话框） | 2 | 24 / 30 / 36 | 48 / 60 / 72 → **取 MinimumSize 80 / 100 / 120** | 75 | 统一 |
| 标签「适配器:」 | 3 + 冒号 ≈ 3.4 | 41 / 51 / 61 | 标签 AutoSize，列 AutoSize | 与下拉框间仅 65px | 原来重叠 |

V1.2 中按钮宽度 = 文字实测宽度（`GetPreferredSize`）+ `Padding.Horizontal`（24 逻辑 px，随 DPI 放大）+ 边框，**因此任何缩放下都满足「Width ≥ 文字实际宽度 + 24px」**；上表是估算值，供核对截图用。

---

## 五、自检清单

### 5.1 优化目标

| # | 目标 | 状态 | 依据 / 说明 |
|---|------|------|-----------|
| 1 | 所有文字、按钮完整显示，无裁剪、无重叠、无遮挡 | ✅ 代码层面已保证；⏳ 需 Windows 截图确认 | 无绝对坐标；按钮 AutoSize；标签 AutoSize；状态栏过长时显示省略号而非被截字 |
| 2 | 100% / 125% / 150% 缩放均不破版 | ✅ 代码层面；⏳ 需三档截图确认 | PerMonitorV2 + AutoScaleMode.Dpi；DataGridView 内部值用 LogicalToDeviceUnits |
| 3 | 窗口拉伸时表格自适应宽度，按钮行保持对齐 | ✅ | 表格位于根 TLP 100% 行、`AutoSizeColumnsMode=Fill`；下拉框列 100%；按钮列 AutoSize 靠右对齐 |
| 4 | 功能、控件命名、事件处理逻辑完全不变 | ✅ | 见第六节；diff 中所有业务方法零改动（仅 `ApplyUiStateWindow` 增加工作区夹紧，属窗口布局） |
| 5 | 不手写 Resize 事件、不引入第三方库 | ✅ | 全文无 `Resize`/`SizeChanged` 事件；仅引用 System.Management（原有） |
| 6 | 能直接编译 | ✅ | `dotnet build -p:EnableWindowsTargeting=true` 0 错误（Linux 交叉编译）；⏳ 建议在 VS2022 再编一次 |

### 5.2 验收标准

| # | 标准 | 状态 | 说明 |
|---|------|------|------|
| 1 | 1366×768 与 1920×1080 下截图无文字截断 | ⏳ **需要在 Windows 实机截图验证**（这边是 Linux，无法运行 WinForms） | 理论核算见第三节「最小可用宽度」；1366×768@150% 时窗口会被夹到工作区内 |
| 2 | 每个按钮 Width ≥ 文字实际宽度 + 24px | ✅ | `AutoSize` + `Padding(12,0,12,0)`，宽度 = 文字宽 + 24 + 边框；Padding 随 DPI 缩放 |
| 3 | 列宽比例 14/18/18/18/15/15/12 | ✅ | `FillWeight` 逐列设为此值；仅当窗口窄到触发 `MinimumWidth` 时比例会让位于最小宽（防止截字） |
| 4 | 配色：表头蓝 #2E75B6、橙 #E8A33D | ✅ | 表头/品牌栏/主按钮 #2E75B6，恢复 DHCP #E8A33D |

已知限制（如实说明）：
- 程序在两块不同缩放的显示器之间拖动时，WinForms 会重新缩放控件，但 DataGridView 的 `RowTemplate.Height` / 列 `MinimumWidth` / 单元格 Padding 仍保持启动时那块屏幕的换算值（字体会正确变化）。单显示器或同缩放多显示器无影响。
- 白字在 #E8A33D 上对比度偏低（约 2.2:1），这是指定配色；如需更易读可把「恢复 DHCP」文字改为 #333333。
- `ApplicationHighDpiMode`（csproj）只有在调用 `ApplicationConfiguration.Initialize()` 时才生效；本项目以 `Program.cs` 的 `SetHighDpiMode` + manifest 为准，三处取值一致。

---

## 六、【功能自检清单】（8 项锁定功能）

| # | 锁定功能 | 保留证明（字段 / 处理函数） | 状态 |
|---|---------|--------------------------|------|
| 1 | 标题「网络适配器 IP 配置工具」 | V1.3：Designer 中 `this.Text = "网络适配器 IP 配置工具"`，运行时 `ApplyVersionInfo()` 追加「 V1.3.0」 | ✅ |
| 2 | 品牌栏「本软件来自 Loncoo …」+ 链接 | `lblBrand.Text = "本软件来自 Loncoo   "`；`linkSite.Text = "loncoo.com"`，`LinkClicked` 仍打开 https://loncoo.com | ✅ |
| 3 | 适配器下拉框（含 [已连接] 状态） | `_cmbAdapters`，`SelectedIndexChanged += CmbAdapters_SelectedIndexChanged`；`RefreshAdapters()` 中 `$"{adapter.Name} [{adapter.Status}]"` 未改 | ✅ |
| 4 | 当前 IP 显示 | `_lblCurrentIp`，由 `UpdateCurrentIp()` 更新，未改 | ✅ |
| 5 | 刷新适配器 / 恢复 DHCP / 重命名适配器（全称保留） | `_btnRefresh → BtnRefresh_Click`；`_btnDhcp → BtnDhcp_Click`；`_btnRename → BtnRename_Click`（→ `RenameDialog`） | ✅ |
| 6 | 表格 7 列 | `_dgvProfiles` 列 Name：`ProfileName / IP / SubnetMask / Gateway / DNS1 / DNS2 / Apply`，表头文字未改 | ✅ |
| 7 | 每行「应用此 IP」 | `Apply` 列 `Text = "应用此 IP"`、`UseColumnTextForButtonValue = true`；`CellClick += DgvProfiles_CellClick`；`CellValueChanged += DgvProfiles_CellValueChanged` | ✅ |
| 8 | 底栏 保存配置 / + 添加配置 / - 删除选中 + 状态「就绪」 | `_btnSave → BtnSave_Click`；`btnAdd → BtnAddProfile_Click`；`btnDel → BtnDelProfile_Click`；`_lblStatus.Text = "就绪"`，`SetStatus()` 未改 | ✅ |

另：`FormClosing += MainForm_FormClosing`、`LoadConfig() → ApplyUiStateWindow() → Load += RefreshAdapters(selectByUiState: true)` 的调用顺序与 V1.1 相同；`CaptureUiState / SaveCurrentConfig / SaveConfig / NetworkService` 全部未改。

---

## 七、与 V1.1 的统一 diff

同内容另存为 `NetworkIPTool_V1.2_layout.diff`（`a/` = V1.1，`b/` = V1.2；不含 bin/obj 与本文件）。

```diff
diff -ruN a/MainForm.cs b/MainForm.cs
--- a/MainForm.cs	2026-11-09 22:03:21.591194580 +0800
+++ b/MainForm.cs	2026-11-09 22:06:59.400124031 +0800
@@ -22,24 +22,86 @@
     private bool _suppressCellSave;
     private bool _restoringUi;
 
+    // ---- 视觉规范（96 DPI 逻辑像素，由 AutoScaleMode.Dpi 自动按缩放比放大）----
+    private static readonly Color ColorPrimary = ColorTranslator.FromHtml("#2E75B6");
+    private static readonly Color ColorPrimaryHover = ColorTranslator.FromHtml("#265F94");
+    private static readonly Color ColorPrimaryDown = ColorTranslator.FromHtml("#1F4E79");
+    private static readonly Color ColorAccent = ColorTranslator.FromHtml("#E8A33D");
+    private static readonly Color ColorAccentHover = ColorTranslator.FromHtml("#D9922A");
+    private static readonly Color ColorAccentDown = ColorTranslator.FromHtml("#C4821F");
+    private static readonly Color ColorBackground = ColorTranslator.FromHtml("#F5F7FA");
+    private static readonly Color ColorText = ColorTranslator.FromHtml("#333333");
+    private static readonly Color ColorBorder = ColorTranslator.FromHtml("#D0D7E2");
+    private static readonly Color ColorGrid = ColorTranslator.FromHtml("#E5E9F0");
+    private static readonly Color ColorSecondaryHover = ColorTranslator.FromHtml("#EAF2FA");
+    private static readonly Color ColorSecondaryDown = ColorTranslator.FromHtml("#D6E6F5");
+    private static readonly Color ColorSubtleHover = ColorTranslator.FromHtml("#F0F3F7");
+    private static readonly Color ColorSubtleDown = ColorTranslator.FromHtml("#E2E7EE");
+
+    private const string UiFontName = "Microsoft YaHei UI";
+    private const float BodyFontPt = 9f;      // 12px @96DPI
+    private const float BannerFontPt = 10.5f; // 14px @96DPI
+    private const int ButtonHeight = 32;      // 按钮高度
+    private const int ButtonPadX = 12;        // 按钮左右内边距（合计 24）
+    private const int ButtonGap = 8;          // 按钮间距
+    private const int ContainerPad = 12;      // 容器内边距
+    private const int BlockGap = 16;          // 区块间距
+    private const int GridRowHeight = 34;     // 表格行高
+
+    private enum ButtonKind
+    {
+        Primary,
+        Accent,
+        Secondary,
+        Subtle
+    }
+
     public MainForm()
     {
         _configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ip_config.xml");
         _config = new AppConfig();
 
+        SuspendLayout();
+
+        // 以下所有像素值均为 96 DPI 逻辑值；ResumeLayout 时按当前 DPI 统一缩放
+        AutoScaleDimensions = new SizeF(96F, 96F);
+        AutoScaleMode = AutoScaleMode.Dpi;
+
         Text = "网络适配器 IP 配置工具";
-        Size = new Size(960, 620);
-        MinimumSize = new Size(800, 500);
+        Size = new Size(1024, 620);
+        MinimumSize = new Size(1024, 600);
         StartPosition = FormStartPosition.CenterScreen;
-        Font = new Font("Microsoft YaHei UI", 9f);
+        Font = new Font(UiFontName, BodyFontPt);
+        BackColor = ColorBackground;
+        ForeColor = ColorText;
+
+        // ---- 根布局：品牌栏 / 适配器卡片 / 表格 / 底栏 ----
+        var root = new TableLayoutPanel
+        {
+            Dock = DockStyle.Fill,
+            ColumnCount = 1,
+            RowCount = 4,
+            Margin = Padding.Empty,
+            Padding = Padding.Empty,
+            BackColor = ColorBackground
+        };
+        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
+        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // 品牌栏
+        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // 适配器卡片
+        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));  // 表格
+        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // 底栏
 
         // ---- 顶部品牌栏 ----
-        var banner = new Panel
+        var banner = new FlowLayoutPanel
         {
-            Dock = DockStyle.Top,
-            Height = 35,
-            BackColor = Color.FromArgb(51, 122, 183),
-            Padding = new Padding(15, 0, 10, 0)
+            Dock = DockStyle.Fill,
+            AutoSize = true,
+            AutoSizeMode = AutoSizeMode.GrowAndShrink,
+            WrapContents = false,
+            FlowDirection = FlowDirection.LeftToRight,
+            BackColor = ColorPrimary,
+            Margin = Padding.Empty,
+            Padding = new Padding(ContainerPad, 8, ContainerPad, 8)
         };
 
         var lblBrand = new Label
@@ -47,18 +109,21 @@
             Text = "本软件来自 Loncoo   ",
             ForeColor = Color.White,
             AutoSize = true,
-            Location = new Point(15, 9),
-            Font = new Font("Microsoft YaHei UI", 9f)
+            Margin = Padding.Empty,
+            Anchor = AnchorStyles.Left,
+            Font = new Font(UiFontName, BannerFontPt)
         };
 
         var linkSite = new LinkLabel
         {
             Text = "loncoo.com",
             AutoSize = true,
-            Location = new Point(175, 9),
+            Margin = Padding.Empty,
+            Anchor = AnchorStyles.Left,
             LinkColor = Color.FromArgb(200, 230, 255),
             ActiveLinkColor = Color.White,
-            Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Underline),
+            VisitedLinkColor = Color.FromArgb(200, 230, 255),
+            Font = new Font(UiFontName, BannerFontPt, FontStyle.Underline),
             Cursor = Cursors.Hand
         };
         linkSite.LinkClicked += (_, _) =>
@@ -79,136 +144,177 @@
 
         banner.Controls.AddRange(new Control[] { lblBrand, linkSite });
 
-        // ---- 适配器工具栏 ----
-        var toolbar = new Panel
+        // ---- 适配器卡片（选择 + 当前 IP + 适配器操作）----
+        var toolbar = new TableLayoutPanel
         {
-            Dock = DockStyle.Top,
-            Height = 70,
-            Padding = new Padding(10, 8, 10, 8)
-        };
+            Dock = DockStyle.Fill,
+            AutoSize = true,
+            AutoSizeMode = AutoSizeMode.GrowAndShrink,
+            ColumnCount = 5,
+            RowCount = 2,
+            BackColor = Color.White,
+            Margin = new Padding(ContainerPad, ContainerPad, ContainerPad, 0),
+            Padding = new Padding(ContainerPad)
+        };
+        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // 适配器:
+        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));  // 下拉框
+        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // 刷新适配器
+        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // 恢复 DHCP
+        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // 重命名适配器
+        toolbar.RowStyles.Add(new RowStyle(SizeType.AutoSize));
+        toolbar.RowStyles.Add(new RowStyle(SizeType.AutoSize));
 
         var lblAdapter = new Label
         {
             Text = "适配器:",
-            Location = new Point(10, 15),
-            AutoSize = true
+            AutoSize = true,
+            Anchor = AnchorStyles.Left,
+            Margin = new Padding(0, 0, ButtonGap, 0)
         };
 
         _cmbAdapters = new ComboBox
         {
-            Location = new Point(75, 12),
-            Size = new Size(400, 25),
-            DropDownStyle = ComboBoxStyle.DropDownList
+            DropDownStyle = ComboBoxStyle.DropDownList,
+            Anchor = AnchorStyles.Left | AnchorStyles.Right,
+            MinimumSize = new Size(220, 0),
+            Margin = Padding.Empty
         };
         _cmbAdapters.SelectedIndexChanged += CmbAdapters_SelectedIndexChanged;
 
         _btnRefresh = new Button
         {
             Text = "刷新适配器",
-            Location = new Point(490, 10),
-            Size = new Size(100, 28)
+            Margin = new Padding(ButtonGap, 0, 0, 0)
         };
+        StyleButton(_btnRefresh, ButtonKind.Secondary);
         _btnRefresh.Click += BtnRefresh_Click;
 
         _btnDhcp = new Button
         {
             Text = "恢复 DHCP",
-            Location = new Point(600, 10),
-            Size = new Size(100, 28),
-            BackColor = Color.FromArgb(255, 165, 0),
-            ForeColor = Color.White,
-            FlatStyle = FlatStyle.Flat
+            Margin = new Padding(ButtonGap, 0, 0, 0)
         };
+        StyleButton(_btnDhcp, ButtonKind.Accent);
         _btnDhcp.Click += BtnDhcp_Click;
 
         _btnRename = new Button
         {
             Text = "重命名适配器",
-            Location = new Point(710, 10),
-            Size = new Size(110, 28)
+            Margin = new Padding(ButtonGap, 0, 0, 0)
         };
+        StyleButton(_btnRename, ButtonKind.Subtle);
         _btnRename.Click += BtnRename_Click;
 
         _lblCurrentIp = new Label
         {
             Text = "当前 IP: -",
-            Location = new Point(75, 40),
             AutoSize = true,
-            ForeColor = Color.FromArgb(51, 122, 183),
-            Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold)
+            Anchor = AnchorStyles.Left,
+            Margin = new Padding(0, 8, 0, 0),
+            ForeColor = ColorPrimary,
+            Font = new Font(UiFontName, BodyFontPt, FontStyle.Bold)
         };
 
-        toolbar.Controls.AddRange(new Control[]
-        {
-            lblAdapter, _cmbAdapters, _btnRefresh, _btnDhcp, _btnRename, _lblCurrentIp
-        });
+        toolbar.Controls.Add(lblAdapter, 0, 0);
+        toolbar.Controls.Add(_cmbAdapters, 1, 0);
+        toolbar.Controls.Add(_btnRefresh, 2, 0);
+        toolbar.Controls.Add(_btnDhcp, 3, 0);
+        toolbar.Controls.Add(_btnRename, 4, 0);
+        toolbar.Controls.Add(_lblCurrentIp, 1, 1);
+        toolbar.SetColumnSpan(_lblCurrentIp, 4);
 
         // ---- 配置表格 ----
         _dgvProfiles = new DataGridView
         {
             Dock = DockStyle.Fill,
+            Margin = new Padding(ContainerPad, BlockGap, ContainerPad, BlockGap),
             AllowUserToAddRows = false,
             AllowUserToDeleteRows = false,
+            AllowUserToResizeRows = false,
             ReadOnly = false,
             SelectionMode = DataGridViewSelectionMode.FullRowSelect,
             MultiSelect = false,
             RowHeadersVisible = false,
             AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
+            AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None,
+            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
+            ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single,
             BackgroundColor = Color.White,
-            BorderStyle = BorderStyle.None,
+            BorderStyle = BorderStyle.FixedSingle,
             CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
-            GridColor = Color.FromArgb(230, 230, 230),
+            GridColor = ColorGrid,
             ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
             {
-                BackColor = Color.FromArgb(51, 122, 183),
+                BackColor = ColorPrimary,
                 ForeColor = Color.White,
-                Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold),
-                Alignment = DataGridViewContentAlignment.MiddleCenter
+                SelectionBackColor = ColorPrimary,
+                SelectionForeColor = Color.White,
+                Font = new Font(UiFontName, BodyFontPt, FontStyle.Bold),
+                Alignment = DataGridViewContentAlignment.MiddleCenter,
+                Padding = LogicalPadding(4, 8, 4, 8),
+                WrapMode = DataGridViewTriState.False
             },
             DefaultCellStyle = new DataGridViewCellStyle
             {
-                Font = new Font("Microsoft YaHei UI", 9f),
-                SelectionBackColor = Color.FromArgb(200, 220, 240),
-                SelectionForeColor = Color.Black
+                Font = new Font(UiFontName, BodyFontPt),
+                ForeColor = ColorText,
+                BackColor = Color.White,
+                SelectionBackColor = Color.FromArgb(220, 233, 247),
+                SelectionForeColor = ColorText,
+                Padding = LogicalPadding(6, 0, 6, 0),
+                WrapMode = DataGridViewTriState.False
+            },
+            AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
+            {
+                BackColor = Color.FromArgb(249, 251, 253)
             },
             EnableHeadersVisualStyles = false
         };
+        // 行高 34px（逻辑值）→ 按当前 DPI 换算为物理像素
+        _dgvProfiles.RowTemplate.Height = LogicalToDeviceUnits(GridRowHeight);
 
+        // 列宽比例：14 / 18 / 18 / 18 / 15 / 15 / 12（合计 110，按比例填充）
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "ProfileName",
             HeaderText = "配置名称",
-            FillWeight = 12f
+            FillWeight = 14f,
+            MinimumWidth = LogicalToDeviceUnits(90)
         });
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "IP",
             HeaderText = "IP 地址",
-            FillWeight = 18f
+            FillWeight = 18f,
+            MinimumWidth = LogicalToDeviceUnits(110)
         });
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "SubnetMask",
             HeaderText = "子网掩码",
-            FillWeight = 18f
+            FillWeight = 18f,
+            MinimumWidth = LogicalToDeviceUnits(110)
         });
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "Gateway",
             HeaderText = "默认网关",
-            FillWeight = 18f
+            FillWeight = 18f,
+            MinimumWidth = LogicalToDeviceUnits(110)
         });
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "DNS1",
             HeaderText = "首选 DNS",
-            FillWeight = 16f
+            FillWeight = 15f,
+            MinimumWidth = LogicalToDeviceUnits(100)
         });
         _dgvProfiles.Columns.Add(new DataGridViewTextBoxColumn
         {
             Name = "DNS2",
             HeaderText = "备用 DNS",
-            FillWeight = 16f
+            FillWeight = 15f,
+            MinimumWidth = LogicalToDeviceUnits(100)
         });
         _dgvProfiles.Columns.Add(new DataGridViewButtonColumn
         {
@@ -216,79 +322,157 @@
             HeaderText = "操作",
             Text = "应用此 IP",
             UseColumnTextForButtonValue = true,
-            FillWeight = 10f,
+            FlatStyle = FlatStyle.Flat,
+            FillWeight = 12f,
+            MinimumWidth = LogicalToDeviceUnits(96),
             DefaultCellStyle = new DataGridViewCellStyle
             {
-                BackColor = Color.FromArgb(92, 184, 92),
+                BackColor = ColorPrimary,
                 ForeColor = Color.White,
-                Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Bold),
-                Alignment = DataGridViewContentAlignment.MiddleCenter
+                SelectionBackColor = ColorPrimaryHover,
+                SelectionForeColor = Color.White,
+                Font = new Font(UiFontName, BodyFontPt, FontStyle.Bold),
+                Alignment = DataGridViewContentAlignment.MiddleCenter,
+                // 按钮四周留白，避免贴住单元格/表格右边界
+                Padding = LogicalPadding(8, 4, 8, 4)
             }
         });
 
         _dgvProfiles.CellClick += DgvProfiles_CellClick;
         _dgvProfiles.CellValueChanged += DgvProfiles_CellValueChanged;
 
-        // ---- 底栏 ----
-        var bottom = new Panel
+        // ---- 底栏：添加 / 删除 | 状态 | 保存 ----
+        var bottom = new TableLayoutPanel
         {
-            Dock = DockStyle.Bottom,
-            Height = 45,
-            Padding = new Padding(10, 8, 10, 8)
-        };
+            Dock = DockStyle.Fill,
+            AutoSize = true,
+            AutoSizeMode = AutoSizeMode.GrowAndShrink,
+            ColumnCount = 4,
+            RowCount = 1,
+            BackColor = Color.White,
+            Margin = Padding.Empty,
+            Padding = new Padding(ContainerPad, 8, ContainerPad, 8)
+        };
+        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // + 添加配置
+        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // - 删除选中
+        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));  // 状态
+        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));       // 保存配置
+        bottom.RowStyles.Add(new RowStyle(SizeType.AutoSize));
 
         _btnSave = new Button
         {
             Text = "保存配置",
-            Location = new Point(10, 8),
-            Size = new Size(100, 28),
-            BackColor = Color.FromArgb(51, 122, 183),
-            ForeColor = Color.White,
-            FlatStyle = FlatStyle.Flat
+            Margin = new Padding(ButtonGap, 0, 0, 0)
         };
+        StyleButton(_btnSave, ButtonKind.Primary);
         _btnSave.Click += BtnSave_Click;
 
         var btnAdd = new Button
         {
             Text = "+ 添加配置",
-            Location = new Point(120, 8),
-            Size = new Size(100, 28)
+            Margin = Padding.Empty
         };
+        StyleButton(btnAdd, ButtonKind.Secondary);
         btnAdd.Click += BtnAddProfile_Click;
 
         var btnDel = new Button
         {
             Text = "- 删除选中",
-            Location = new Point(230, 8),
-            Size = new Size(100, 28)
+            Margin = new Padding(ButtonGap, 0, 0, 0)
         };
+        StyleButton(btnDel, ButtonKind.Secondary);
         btnDel.Click += BtnDelProfile_Click;
 
         _lblStatus = new Label
         {
             Text = "就绪",
-            Location = new Point(350, 14),
-            AutoSize = true,
+            AutoSize = false,
+            AutoEllipsis = true,
+            Dock = DockStyle.Fill,
+            TextAlign = ContentAlignment.MiddleLeft,
+            Margin = new Padding(BlockGap, 0, ButtonGap, 0),
             ForeColor = Color.Gray
         };
 
-        bottom.Controls.AddRange(new Control[] { _btnSave, btnAdd, btnDel, _lblStatus });
-
-        // 添加顺序：Fill 最先，再 Bottom/Top，最后 Top 会压在最上
-        Controls.Add(_dgvProfiles);
-        Controls.Add(bottom);
-        Controls.Add(toolbar);
-        Controls.Add(banner);
+        bottom.Controls.Add(btnAdd, 0, 0);
+        bottom.Controls.Add(btnDel, 1, 0);
+        bottom.Controls.Add(_lblStatus, 2, 0);
+        bottom.Controls.Add(_btnSave, 3, 0);
+
+        root.Controls.Add(banner, 0, 0);
+        root.Controls.Add(toolbar, 0, 1);
+        root.Controls.Add(_dgvProfiles, 0, 2);
+        root.Controls.Add(bottom, 0, 3);
+        Controls.Add(root);
 
         FormClosing += MainForm_FormClosing;
 
+        // 结束挂起：此时按当前 DPI 一次性缩放 Size / MinimumSize / Padding / Margin
+        ResumeLayout(false);
+        PerformLayout();
+
         // 在首次显示前加载配置并还原窗口，避免闪一下居中再跳位
+        // （放在 ResumeLayout 之后，保存的物理像素尺寸不会被二次缩放）
         LoadConfig();
         ApplyUiStateWindow();
         // 句柄创建后再枚举网卡（WMI），保证下拉框可用
         Load += (_, _) => RefreshAdapters(selectByUiState: true);
     }
 
+    // ----------------- 布局辅助（仅外观，不含业务逻辑） -----------------
+
+    /// <summary>按钮统一规格：AutoSize 随文字伸缩，宽 = 文字宽 + 24px，高 ≥ 32px。</summary>
+    private static void StyleButton(Button button, ButtonKind kind)
+    {
+        button.AutoSize = true;
+        button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
+        button.MinimumSize = new Size(0, ButtonHeight);
+        button.Padding = new Padding(ButtonPadX, 0, ButtonPadX, 0);
+        button.Anchor = AnchorStyles.Left;
+        button.TextAlign = ContentAlignment.MiddleCenter;
+        button.UseVisualStyleBackColor = false;
+        button.FlatStyle = FlatStyle.Flat;
+        button.FlatAppearance.BorderSize = 1;
+        button.Cursor = Cursors.Hand;
+
+        switch (kind)
+        {
+            case ButtonKind.Primary:
+                button.BackColor = ColorPrimary;
+                button.ForeColor = Color.White;
+                button.FlatAppearance.BorderColor = ColorPrimary;
+                button.FlatAppearance.MouseOverBackColor = ColorPrimaryHover;
+                button.FlatAppearance.MouseDownBackColor = ColorPrimaryDown;
+                break;
+            case ButtonKind.Accent:
+                button.BackColor = ColorAccent;
+                button.ForeColor = Color.White;
+                button.FlatAppearance.BorderColor = ColorAccent;
+                button.FlatAppearance.MouseOverBackColor = ColorAccentHover;
+                button.FlatAppearance.MouseDownBackColor = ColorAccentDown;
+                break;
+            case ButtonKind.Secondary:
+                button.BackColor = Color.White;
+                button.ForeColor = ColorPrimary;
+                button.FlatAppearance.BorderColor = ColorPrimary;
+                button.FlatAppearance.MouseOverBackColor = ColorSecondaryHover;
+                button.FlatAppearance.MouseDownBackColor = ColorSecondaryDown;
+                break;
+            default:
+                button.BackColor = Color.White;
+                button.ForeColor = Color.FromArgb(85, 85, 85);
+                button.FlatAppearance.BorderColor = ColorBorder;
+                button.FlatAppearance.MouseOverBackColor = ColorSubtleHover;
+                button.FlatAppearance.MouseDownBackColor = ColorSubtleDown;
+                break;
+        }
+    }
+
+    /// <summary>DataGridView 单元格 Padding 不参与 AutoScale，这里按 DPI 手动换算一次。</summary>
+    private Padding LogicalPadding(int left, int top, int right, int bottom) =>
+        new(LogicalToDeviceUnits(left), LogicalToDeviceUnits(top),
+            LogicalToDeviceUnits(right), LogicalToDeviceUnits(bottom));
+
     // ----------------- UI 状态 -----------------
 
     private void ApplyUiStateWindow()
@@ -296,28 +480,31 @@
         UiState ui = _config.UiState ?? new UiState();
         _config.UiState = ui;
 
-        int w = ui.WindowWidth > 0 ? ui.WindowWidth : 960;
-        int h = ui.WindowHeight > 0 ? ui.WindowHeight : 620;
-        w = Math.Max(w, MinimumSize.Width);
-        h = Math.Max(h, MinimumSize.Height);
+        // 此时 Size / MinimumSize 已按 DPI 缩放；保存值为 0 表示用默认尺寸
+        int w = ui.WindowWidth > 0 ? ui.WindowWidth : Width;
+        int h = ui.WindowHeight > 0 ? ui.WindowHeight : Height;
 
         bool hasPos = ui.WindowX >= 0 && ui.WindowY >= 0;
-        if (hasPos)
-        {
-            // 确保窗口大致落在可见屏幕内
-            var bounds = new Rectangle(ui.WindowX, ui.WindowY, w, h);
-            bool onScreen = Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(bounds));
-            if (onScreen)
-            {
-                StartPosition = FormStartPosition.Manual;
-                Location = new Point(ui.WindowX, ui.WindowY);
-                Size = new Size(w, h);
-            }
-            else
-            {
-                StartPosition = FormStartPosition.CenterScreen;
-                Size = new Size(w, h);
-            }
+        var bounds = new Rectangle(ui.WindowX, ui.WindowY, w, h);
+        bool onScreen = hasPos && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(bounds));
+
+        // 目标屏幕工作区：小屏高缩放（如 1366×768 @150%）时，最小尺寸与窗口尺寸都收缩到工作区内
+        Rectangle area = onScreen
+            ? Screen.FromRectangle(bounds).WorkingArea
+            : Screen.FromPoint(Cursor.Position).WorkingArea;
+        MinimumSize = new Size(
+            Math.Min(MinimumSize.Width, area.Width),
+            Math.Min(MinimumSize.Height, area.Height));
+        w = Math.Clamp(w, MinimumSize.Width, area.Width);
+        h = Math.Clamp(h, MinimumSize.Height, area.Height);
+
+        if (onScreen)
+        {
+            StartPosition = FormStartPosition.Manual;
+            int x = Math.Clamp(ui.WindowX, area.Left, area.Right - w);
+            int y = Math.Clamp(ui.WindowY, area.Top, area.Bottom - h);
+            Location = new Point(x, y);
+            Size = new Size(w, h);
         }
         else
         {
diff -ruN a/Models/UiState.cs b/Models/UiState.cs
--- a/Models/UiState.cs	2026-11-09 22:03:21.591194580 +0800
+++ b/Models/UiState.cs	2026-11-09 22:07:25.261458187 +0800
@@ -11,11 +11,11 @@
     /// <summary>窗口上边距（屏幕坐标）。</summary>
     public int WindowY { get; set; } = -1;
 
-    /// <summary>窗口宽度。</summary>
-    public int WindowWidth { get; set; } = 960;
+    /// <summary>窗口宽度（物理像素）。0 表示使用默认尺寸（1024 逻辑像素 × 当前缩放）。</summary>
+    public int WindowWidth { get; set; } = 0;
 
-    /// <summary>窗口高度。</summary>
-    public int WindowHeight { get; set; } = 620;
+    /// <summary>窗口高度（物理像素）。0 表示使用默认尺寸（620 逻辑像素 × 当前缩放）。</summary>
+    public int WindowHeight { get; set; } = 0;
 
     /// <summary>窗口状态：Normal / Maximized（Minimized 会按 Normal 还原）。</summary>
     public string WindowState { get; set; } = "Normal";
diff -ruN a/NetworkIPTool.csproj b/NetworkIPTool.csproj
--- a/NetworkIPTool.csproj	2026-11-09 22:03:21.591194580 +0800
+++ b/NetworkIPTool.csproj	2026-11-09 22:07:25.265459012 +0800
@@ -11,10 +11,13 @@
     <AssemblyName>NetworkIPTool</AssemblyName>
     <ApplicationIcon>app.ico</ApplicationIcon>
     <ApplicationManifest>app.manifest</ApplicationManifest>
-    <Version>1.1.0</Version>
-    <AssemblyVersion>1.1.0.0</AssemblyVersion>
-    <FileVersion>1.1.0.0</FileVersion>
-    <InformationalVersion>1.1.0</InformationalVersion>
+    <ApplicationHighDpiMode>PerMonitorV2</ApplicationHighDpiMode>
+    <!-- WFAC010：manifest 与代码同时声明 DPI 模式时的提示；两处均为 PerMonitorV2，保持一致即可 -->
+    <NoWarn>$(NoWarn);WFAC010</NoWarn>
+    <Version>1.2.0</Version>
+    <AssemblyVersion>1.2.0.0</AssemblyVersion>
+    <FileVersion>1.2.0.0</FileVersion>
+    <InformationalVersion>1.2.0</InformationalVersion>
     <Product>网络适配器 IP 配置工具</Product>
     <Company>Loncoo</Company>
     <Authors>Loncoo</Authors>
diff -ruN a/Program.cs b/Program.cs
--- a/Program.cs	2026-11-09 22:03:21.591194580 +0800
+++ b/Program.cs	2026-11-09 22:07:25.261458187 +0800
@@ -8,7 +8,8 @@
     [STAThread]
     private static void Main()
     {
-        Application.SetHighDpiMode(HighDpiMode.SystemAware);
+        // 必须在创建任何窗口之前调用；与 app.manifest / csproj 中的 PerMonitorV2 保持一致
+        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
         Application.EnableVisualStyles();
         Application.SetCompatibleTextRenderingDefault(false);
         Application.Run(new MainForm());
diff -ruN a/README.md b/README.md
--- a/README.md	2026-11-09 22:03:21.591194580 +0800
+++ b/README.md	2026-11-09 22:07:52.271029179 +0800
@@ -1,4 +1,4 @@
-# 网络适配器 IP 配置工具 (NetworkIPTool) v1.1
+# 网络适配器 IP 配置工具 (NetworkIPTool) v1.2
 
 Windows 网卡 IP 配置小工具：为每个适配器保存多套静态 IP（掩码 / 网关 / DNS），一键应用或恢复 DHCP，支持重命名网卡。
 
@@ -46,7 +46,7 @@
 路径：与 `NetworkIPTool.exe` 同目录的 `ip_config.xml`。
 
 - `Adapters` / `AdapterProfile` / `IPConfig`：与 V1.01 相同，可直接迁移旧文件
-- `UiState`（V1.1 新增，缺失时用默认值）：
+- `UiState`（V1.1 新增，缺失时用默认值；V1.2 起宽高为 0 表示按 DPI 使用默认尺寸）：
   - `WindowX` / `WindowY` / `WindowWidth` / `WindowHeight`
   - `WindowState`：`Normal` 或 `Maximized`（若上次是最小化，下次按 Normal 打开）
   - `LastAdapterName`：上次选中的适配器名称
@@ -70,7 +70,8 @@
 │   └── UiState.cs
 ├── ip_config.xml          # 示例配置（复制到输出目录）
 ├── app.ico
-├── app.manifest           # requireAdministrator
+├── app.manifest           # requireAdministrator + PerMonitorV2
+├── LAYOUT_FIX.md          # V1.2 布局 / 高 DPI 修复说明
 └── README.md
 ```
 
@@ -82,7 +83,9 @@
 | 管理员提权 | 清单 `requireAdministrator`；`netsh` 仅重定向输出，不再错误地设 `Verb=runas` |
 | 枚举/属性 | 使用 `FormStartPosition.CenterScreen`、`ComboBoxStyle.DropDownList` 等正确枚举 |
 | 界面记忆 | 退出时写入 `UiState`，启动时还原窗口与选中项 |
-| 版本号 | 1.1.0 |
+| 高 DPI（V1.2） | PerMonitorV2 + `AutoScaleMode.Dpi`；TableLayoutPanel/FlowLayoutPanel 自适应布局，按钮 AutoSize，详见 `LAYOUT_FIX.md` |
+| 视觉（V1.2） | 主色 #2E75B6、强调色 #E8A33D、背景 #F5F7FA；按钮主/次/弱三级层次 |
+| 版本号 | 1.2.0 |
 
 ## 许可 / 品牌
 
diff -ruN a/RenameDialog.cs b/RenameDialog.cs
--- a/RenameDialog.cs	2026-11-09 22:03:21.591194580 +0800
+++ b/RenameDialog.cs	2026-11-09 22:07:25.265459012 +0800
@@ -11,36 +11,63 @@
 
     public RenameDialog(string currentName)
     {
+        SuspendLayout();
+
+        // 逻辑像素基准 96 DPI，ResumeLayout 时按当前 DPI 缩放
+        AutoScaleDimensions = new SizeF(96F, 96F);
+        AutoScaleMode = AutoScaleMode.Dpi;
+
         Text = "重命名适配器";
-        Size = new Size(380, 160);
         StartPosition = FormStartPosition.CenterParent;
         FormBorderStyle = FormBorderStyle.FixedDialog;
         MaximizeBox = false;
         MinimizeBox = false;
         Font = new Font("Microsoft YaHei UI", 9f);
         ShowInTaskbar = false;
+        BackColor = ColorTranslator.FromHtml("#F5F7FA");
+        ForeColor = ColorTranslator.FromHtml("#333333");
+        // 窗口大小由内容决定，不再写死 380×160
+        AutoSize = true;
+        AutoSizeMode = AutoSizeMode.GrowAndShrink;
+        Padding = new Padding(12);
+
+        var layout = new TableLayoutPanel
+        {
+            AutoSize = true,
+            AutoSizeMode = AutoSizeMode.GrowAndShrink,
+            ColumnCount = 2,
+            RowCount = 2,
+            Dock = DockStyle.Fill,
+            Margin = Padding.Empty
+        };
+        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
+        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
+        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
+        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
 
         var lbl = new Label
         {
             Text = "新名称:",
-            Location = new Point(15, 20),
-            AutoSize = true
+            AutoSize = true,
+            Anchor = AnchorStyles.Left,
+            Margin = new Padding(0, 0, 8, 0)
         };
 
         _txtName = new TextBox
         {
             Text = currentName,
-            Location = new Point(70, 17),
-            Size = new Size(270, 25)
+            Anchor = AnchorStyles.Left | AnchorStyles.Right,
+            MinimumSize = new Size(280, 0),
+            Width = 280,
+            Margin = Padding.Empty
         };
 
         var btnOk = new Button
         {
             Text = "确定",
-            Location = new Point(180, 70),
-            Size = new Size(75, 28),
             DialogResult = DialogResult.OK
         };
+        StyleDialogButton(btnOk, primary: true);
         btnOk.Click += (_, _) =>
         {
             NewName = _txtName.Text.Trim();
@@ -50,13 +77,63 @@
         var btnCancel = new Button
         {
             Text = "取消",
-            Location = new Point(265, 70),
-            Size = new Size(75, 28),
             DialogResult = DialogResult.Cancel
         };
+        StyleDialogButton(btnCancel, primary: false);
+
+        // 按钮行右对齐：RightToLeft 流向，先加的“取消”在最右
+        var buttons = new FlowLayoutPanel
+        {
+            AutoSize = true,
+            AutoSizeMode = AutoSizeMode.GrowAndShrink,
+            FlowDirection = FlowDirection.RightToLeft,
+            WrapContents = false,
+            Anchor = AnchorStyles.Right,
+            Margin = new Padding(0, 16, 0, 0),
+            Padding = Padding.Empty
+        };
+        buttons.Controls.Add(btnCancel);
+        buttons.Controls.Add(btnOk);
 
-        Controls.AddRange(new Control[] { lbl, _txtName, btnOk, btnCancel });
+        layout.Controls.Add(lbl, 0, 0);
+        layout.Controls.Add(_txtName, 1, 0);
+        layout.Controls.Add(buttons, 0, 1);
+        layout.SetColumnSpan(buttons, 2);
+
+        Controls.Add(layout);
         AcceptButton = btnOk;
         CancelButton = btnCancel;
+
+        ResumeLayout(false);
+        PerformLayout();
+    }
+
+    /// <summary>与主窗口一致：AutoSize + 左右各 12px 内边距 + 最小 80×32。</summary>
+    private static void StyleDialogButton(Button button, bool primary)
+    {
+        Color blue = ColorTranslator.FromHtml("#2E75B6");
+        button.AutoSize = true;
+        button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
+        button.MinimumSize = new Size(80, 32);
+        button.Padding = new Padding(12, 0, 12, 0);
+        button.Margin = new Padding(8, 0, 0, 0);
+        button.UseVisualStyleBackColor = false;
+        button.FlatStyle = FlatStyle.Flat;
+        button.FlatAppearance.BorderSize = 1;
+        button.FlatAppearance.BorderColor = blue;
+        if (primary)
+        {
+            button.BackColor = blue;
+            button.ForeColor = Color.White;
+            button.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml("#265F94");
+            button.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml("#1F4E79");
+        }
+        else
+        {
+            button.BackColor = Color.White;
+            button.ForeColor = blue;
+            button.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml("#EAF2FA");
+            button.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml("#D6E6F5");
+        }
     }
 }
diff -ruN a/app.manifest b/app.manifest
--- a/app.manifest	2026-11-09 22:03:21.591194580 +0800
+++ b/app.manifest	2026-11-09 22:07:25.265459012 +0800
@@ -1,6 +1,6 @@
 <?xml version="1.0" encoding="utf-8"?>
 <assembly manifestVersion="1.0" xmlns="urn:schemas-microsoft-com:asm.v1">
-  <assemblyIdentity version="1.1.0.0" name="NetworkIPTool"/>
+  <assemblyIdentity version="1.2.0.0" name="NetworkIPTool"/>
   <trustInfo xmlns="urn:schemas-microsoft-com:asm.v2">
     <security>
       <requestedPrivileges xmlns="urn:schemas-microsoft-com:asm.v3">
@@ -20,4 +20,11 @@
       <supportedOS Id="{35138b9a-5d96-4fbd-8e2d-a2440225f93a}" />
     </application>
   </compatibility>
+  <!-- 高 DPI：Per-Monitor V2（Win10 1703+），旧系统回退为 System DPI aware -->
+  <application xmlns="urn:schemas-microsoft-com:asm.v3">
+    <windowsSettings>
+      <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true/PM</dpiAware>
+      <dpiAwareness xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">PerMonitorV2, PerMonitor</dpiAwareness>
+    </windowsSettings>
+  </application>
 </assembly>
```
